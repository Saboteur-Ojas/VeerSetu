import { 
  Intervention, 
  SupportProfessional, 
  AttentionItem, 
  RecentActivityItem, 
  SubUnitData, 
  UserProfile,
  NotificationItem,
  NotificationSettings,
  DashboardPreferences
} from '../types';

export const INITIAL_USER: UserProfile = {
  id: 'usr-cmd-01',
  name: 'Vikramjit S. Rathore',
  serviceId: 'CAPF-782190',
  email: 'commandant.142bn@capf.gov.in',
  phone: '+91 94191 88421',
  rank: 'Commandant',
  unit: '142 Battalion, BSF · Sector Jammu',
  role: 'Commandant',
  twoFactorEnabled: true,
};

export const SUPPORT_PROFESSIONALS: SupportProfessional[] = [
  {
    id: 'prof-01',
    name: 'Dr. Ananya Sharma',
    role: 'Clinical Psychologist',
    designation: 'CAPF Composite Hospital Counsellor',
    contact: '+91 98210 44219',
    activeCasesCount: 4,
  },
  {
    id: 'prof-02',
    name: 'Subedar Major S. K. Negi',
    role: 'Welfare Officer',
    designation: 'Unit Welfare & Grievance Cell',
    contact: '+91 94192 11029',
    activeCasesCount: 3,
  },
  {
    id: 'prof-03',
    name: 'Dr. Rohit Verma',
    role: 'Senior Medical Officer',
    designation: '142 Bn Unit Hospital',
    contact: '+91 98110 55902',
    activeCasesCount: 2,
  },
  {
    id: 'prof-04',
    name: 'Inspector Meena Sen',
    role: 'Family Welfare Officer',
    designation: 'BWWA / Regional Welfare Wing',
    contact: '+91 97182 33490',
    activeCasesCount: 2,
  },
  {
    id: 'prof-05',
    name: 'Inspector R. K. Yadav',
    role: 'Administrative Support Officer',
    designation: 'Battalion HQ Adjutant Branch',
    contact: '+91 94190 77312',
    activeCasesCount: 1,
  }
];

export const SUB_UNITS_DATA: SubUnitData[] = [
  {
    id: 'coy-hq',
    name: 'HQ Company',
    personnelCount: 220,
    checkInRate: 94.5,
    activeRequests: 2,
    ongoingInterventions: 1,
    location: 'Battalion Headquarters, RS Pura',
    commanderInCharge: 'Maj. D. K. Joshi',
  },
  {
    id: 'coy-a',
    name: 'Alpha Company',
    personnelCount: 235,
    checkInRate: 92.1,
    activeRequests: 3,
    ongoingInterventions: 2,
    location: 'Forward Post Alpha, Suchetgarh',
    commanderInCharge: 'Assistant Commandant A. Roy',
  },
  {
    id: 'coy-b',
    name: 'Bravo Company',
    personnelCount: 228,
    checkInRate: 88.6,
    activeRequests: 4,
    ongoingInterventions: 2,
    location: 'Border Outpost Line, Arnia Sector',
    commanderInCharge: 'Assistant Commandant P. Chawla',
  },
  {
    id: 'coy-c',
    name: 'Charlie Company',
    personnelCount: 242,
    checkInRate: 84.3,
    activeRequests: 6,
    ongoingInterventions: 3,
    location: 'Riverine Outpost Detachment, Pargwal',
    commanderInCharge: 'Deputy Commandant M. S. Gill',
  },
  {
    id: 'coy-d',
    name: 'Delta Company',
    personnelCount: 215,
    checkInRate: 93.8,
    activeRequests: 2,
    ongoingInterventions: 1,
    location: 'Reserve & Quick Reaction Base, Jammu',
    commanderInCharge: 'Assistant Commandant S. Tirkey',
  },
];

export const INITIAL_INTERVENTIONS: Intervention[] = [
  {
    id: 'INT-2026-104',
    category: 'Family Welfare',
    createdAt: '2026-09-02T09:30:00Z',
    updatedAt: '2026-09-04T08:15:00Z',
    status: 'In Progress',
    priority: 'Urgent',
    assignedProfessionalId: 'prof-04',
    assignedProfessionalName: 'Inspector Meena Sen (Family Welfare)',
    subUnit: 'Charlie Company',
    summary: 'Coordinate specialized paediatric medical liaison and emergency leave paperwork for remote border outpost personnel family member.',
    nextFollowUpDate: '2026-09-05',
    notes: [
      {
        id: 'note-101',
        timestamp: '2026-09-02T10:15:00Z',
        authorName: 'Subedar Major S. K. Negi',
        authorRole: 'Welfare Officer',
        content: 'Support request validated via automated intake channel. Personnel family at native place requires urgent tertiary hospital referral assistance.',
      },
      {
        id: 'note-102',
        timestamp: '2026-09-03T14:30:00Z',
        authorName: 'Inspector Meena Sen',
        authorRole: 'Family Welfare Officer',
        content: 'Contacted Base Hospital empanelled coordinator in hometown. Bed admission confirmed. Personnel briefed on approved compassionate leave authorization.',
      }
    ],
  },
  {
    id: 'INT-2026-102',
    category: 'Counselling Support',
    createdAt: '2026-08-30T11:20:00Z',
    updatedAt: '2026-09-03T16:00:00Z',
    status: 'In Progress',
    priority: 'High',
    assignedProfessionalId: 'prof-01',
    assignedProfessionalName: 'Dr. Ananya Sharma (Clinical Psychologist)',
    subUnit: 'Bravo Company',
    summary: 'Facilitating stress decompression sessions following continuous 18-day high-alert border outpost duty rotation.',
    nextFollowUpDate: '2026-09-06',
    notes: [
      {
        id: 'note-201',
        timestamp: '2026-08-30T12:00:00Z',
        authorName: 'Dr. Ananya Sharma',
        authorRole: 'Clinical Psychologist',
        content: 'Initial tele-consultation conducted under private protocol. Provided mindfulness and progressive sleep hygiene routines for outpost conditions.',
      },
      {
        id: 'note-202',
        timestamp: '2026-09-02T15:45:00Z',
        authorName: 'Dr. Rohit Verma',
        authorRole: 'Senior Medical Officer',
        content: 'Duty rest schedule modified in coordination with Company 2IC. Positive adaptation reported.',
      }
    ]
  },
  {
    id: 'INT-2026-099',
    category: 'Administrative Support',
    createdAt: '2026-08-25T08:00:00Z',
    updatedAt: '2026-09-01T11:10:00Z',
    status: 'Follow-up',
    priority: 'Medium',
    assignedProfessionalId: 'prof-05',
    assignedProfessionalName: 'Inspector R. K. Yadav (HQ Adjutant Branch)',
    subUnit: 'HQ Company',
    summary: 'Resolution of delayed dependent education grant processing through Central Police Welfare Fund portal.',
    nextFollowUpDate: '2026-09-07',
    notes: [
      {
        id: 'note-301',
        timestamp: '2026-08-25T09:30:00Z',
        authorName: 'Inspector R. K. Yadav',
        authorRole: 'Administrative Support Officer',
        content: 'Document verification completed with Pay & Accounts Office. Scholarship approval expedited.',
      }
    ]
  },
  {
    id: 'INT-2026-096',
    category: 'Personal Assistance',
    createdAt: '2026-08-21T14:15:00Z',
    updatedAt: '2026-09-02T17:30:00Z',
    status: 'Follow-up',
    priority: 'High',
    assignedProfessionalId: 'prof-02',
    assignedProfessionalName: 'Subedar Major S. K. Negi (Welfare Officer)',
    subUnit: 'Charlie Company',
    summary: 'Legal and administrative advisory support for family land boundary dispute affecting personnel peace of mind.',
    nextFollowUpDate: '2026-09-08',
    notes: [
      {
        id: 'note-401',
        timestamp: '2026-08-22T10:00:00Z',
        authorName: 'Subedar Major S. K. Negi',
        authorRole: 'Welfare Officer',
        content: 'Official letter dispatched from Commandant office to District Magistrate of personnel home district requesting administrative verification.',
      },
      {
        id: 'note-402',
        timestamp: '2026-09-01T14:20:00Z',
        authorName: 'Subedar Major S. K. Negi',
        authorRole: 'Welfare Officer',
        content: 'District Administration acknowledged receipt; local Revenue Officer assigned for spot inspection.',
      }
    ]
  },
  {
    id: 'INT-2026-093',
    category: 'Medical Liaison',
    createdAt: '2026-08-18T10:00:00Z',
    updatedAt: '2026-08-29T16:00:00Z',
    status: 'Completed',
    priority: 'Medium',
    assignedProfessionalId: 'prof-03',
    assignedProfessionalName: 'Dr. Rohit Verma (Senior Medical Officer)',
    subUnit: 'Alpha Company',
    summary: 'Physiotherapy rehabilitation schedule and medical category review post-ankle ligament strain during obstacle training.',
    resolutionSummary: 'Completed 6 weeks of monitored physical therapy at Unit MI Room. Fit certificate issued with full duty clearance.',
    notes: [
      {
        id: 'note-501',
        timestamp: '2026-08-18T11:00:00Z',
        authorName: 'Dr. Rohit Verma',
        authorRole: 'Senior Medical Officer',
        content: 'Therapy protocols established. Light duty assigned for 14 days.',
      },
      {
        id: 'note-502',
        timestamp: '2026-08-29T15:30:00Z',
        authorName: 'Dr. Rohit Verma',
        authorRole: 'Senior Medical Officer',
        content: 'Final joint mobility evaluation normal. Case formally concluded with medical clearance.',
      }
    ]
  },
  {
    id: 'INT-2026-091',
    category: 'Post-Deployment Reintegration',
    createdAt: '2026-08-15T09:40:00Z',
    updatedAt: '2026-09-03T10:20:00Z',
    status: 'Assigned',
    priority: 'Medium',
    assignedProfessionalId: 'prof-01',
    assignedProfessionalName: 'Dr. Ananya Sharma (Clinical Psychologist)',
    subUnit: 'Delta Company',
    summary: 'Post-deployment debriefing and sleep rhythm re-adjustment following 6-month high-altitude tenure in Ladakh.',
    nextFollowUpDate: '2026-09-09',
    notes: [
      {
        id: 'note-601',
        timestamp: '2026-08-16T10:00:00Z',
        authorName: 'Subedar Major S. K. Negi',
        authorRole: 'Welfare Officer',
        content: 'Initial decompression schedule prepared. Assigned to Composite Hospital counselling cell.',
      }
    ]
  },
  {
    id: 'INT-2026-088',
    category: 'Counselling Support',
    createdAt: '2026-08-12T13:00:00Z',
    updatedAt: '2026-08-28T14:45:00Z',
    status: 'Completed',
    priority: 'Low',
    assignedProfessionalId: 'prof-01',
    assignedProfessionalName: 'Dr. Ananya Sharma (Clinical Psychologist)',
    subUnit: 'HQ Company',
    summary: 'Routine supportive counselling and peer adaptation sessions for newly inducted subordinate officers.',
    resolutionSummary: 'Completed 3 structured guidance sessions. Personnel well-adapted to battalion operational tempo.',
    notes: [
      {
        id: 'note-701',
        timestamp: '2026-08-12T14:00:00Z',
        authorName: 'Dr. Ananya Sharma',
        authorRole: 'Clinical Psychologist',
        content: 'Orientation sessions concluded with commendable engagement.',
      }
    ]
  },
  {
    id: 'INT-2026-107',
    category: 'Personal Assistance',
    createdAt: '2026-09-03T15:20:00Z',
    updatedAt: '2026-09-04T07:45:00Z',
    status: 'Created',
    priority: 'High',
    subUnit: 'Alpha Company',
    summary: 'Assistance requested for emergency home travel logistics due to sudden ancestral property inundation in flood-affected state.',
    notes: [
      {
        id: 'note-801',
        timestamp: '2026-09-03T15:30:00Z',
        authorName: 'Duty NCO',
        authorRole: 'Company Welfare NCO',
        content: 'Request forwarded to Battalion Adjutant for emergency rail requisition voucher generation.',
      }
    ]
  }
];

export const ATTENTION_ITEMS: AttentionItem[] = [
  {
    id: 'att-1',
    title: 'Cluster of Family Support Inquiries in Charlie Company',
    description: 'Charlie Company (Riverine Outpost) has recorded 6 new family welfare requests this fortnight. Recommend review of leave rotation schedule.',
    priority: 'Urgent',
    category: 'Operational Welfare',
    timestamp: 'Today, 08:30 AM',
    relatedSubUnit: 'Charlie Company',
    actionText: 'View Charlie Coy',
    targetPage: 'unit-overview',
  },
  {
    id: 'att-2',
    title: 'High-Priority Case #INT-2026-104 Follow-up Due',
    description: 'Paediatric hospital liaison in hometown requires verification of approved financial disbursement.',
    priority: 'Urgent',
    category: 'Case Milestone',
    timestamp: 'Today, 07:15 AM',
    relatedInterventionId: 'INT-2026-104',
    actionText: 'Open Case',
    targetPage: 'interventions',
  },
  {
    id: 'att-3',
    title: 'Bravo Company Check-In Rate Slight Dip (88.6%)',
    description: 'Check-in completion rate dipped 4.2% following recent inclement weather communications disruption in Arnia sector.',
    priority: 'Moderate',
    category: 'Participation Pattern',
    timestamp: 'Yesterday, 18:20 PM',
    relatedSubUnit: 'Bravo Company',
    actionText: 'Inspect Unit Trends',
    targetPage: 'unit-overview',
  },
  {
    id: 'att-4',
    title: 'Unassigned Case #INT-2026-107 Pending Professional Allocation',
    description: 'Emergency travel assistance initiated in Alpha Company requires Adjutant Branch coordination.',
    priority: 'Operational',
    category: 'Action Pending',
    timestamp: 'Yesterday, 15:40 PM',
    relatedInterventionId: 'INT-2026-107',
    actionText: 'Assign Professional',
    targetPage: 'interventions',
  }
];

export const RECENT_ACTIVITIES: RecentActivityItem[] = [
  {
    id: 'act-1',
    timestamp: 'Today, 08:15 AM',
    title: 'Follow-up Note Added',
    description: 'Family Welfare Officer updated paediatric bed admission status for Case #INT-2026-104',
    type: 'followup_logged',
    interventionId: 'INT-2026-104',
    subUnit: 'Charlie Company',
  },
  {
    id: 'act-2',
    timestamp: 'Today, 07:45 AM',
    title: 'New Support Request Created',
    description: 'Emergency travel assistance request generated for Alpha Company personnel',
    type: 'request_received',
    interventionId: 'INT-2026-107',
    subUnit: 'Alpha Company',
  },
  {
    id: 'act-3',
    timestamp: 'Yesterday, 16:00 PM',
    title: 'Counselling Session Completed',
    description: 'Decompression guidance session concluded for Case #INT-2026-102 (Bravo Coy)',
    type: 'status_updated',
    interventionId: 'INT-2026-102',
    subUnit: 'Bravo Company',
  },
  {
    id: 'act-4',
    timestamp: '2 days ago',
    title: 'Intervention Successfully Concluded',
    description: 'Ankle rehabilitation and physical clearance concluded for Case #INT-2026-093',
    type: 'completed',
    interventionId: 'INT-2026-093',
    subUnit: 'Alpha Company',
  },
  {
    id: 'act-5',
    timestamp: '3 days ago',
    title: 'Officer Assigned',
    description: 'Inspector R. K. Yadav assigned to Dependent Education Grant Liaison #INT-2026-099',
    type: 'assigned',
    interventionId: 'INT-2026-099',
    subUnit: 'HQ Company',
  }
];

export const PARTICIPATION_TRENDS = [
  { week: 'Week 1', rate: 91.2, responses: 1040, requests: 12 },
  { week: 'Week 2', rate: 92.5, responses: 1054, requests: 10 },
  { week: 'Week 3', rate: 89.8, responses: 1024, requests: 16 },
  { week: 'Week 4', rate: 93.4, responses: 1065, requests: 11 },
  { week: 'Week 5', rate: 90.7, responses: 1034, requests: 15 },
  { week: 'Week 6 (Current)', rate: 91.4, responses: 1042, requests: 14 },
];

export const CATEGORY_BREAKDOWN = [
  { name: 'Family & Domestic Welfare', value: 32, count: 11, color: '#3B82F6' },
  { name: 'Counselling & Stress Care', value: 24, count: 8, color: '#0D9488' },
  { name: 'Medical Liaison', value: 20, count: 7, color: '#6366F1' },
  { name: 'Personal & Legal Assistance', value: 15, count: 5, color: '#F59E0B' },
  { name: 'Post-Deployment Reintegration', value: 9, count: 3, color: '#8B5CF6' },
];

export const DEFAULT_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Urgent Family Welfare Case Assigned',
    message: 'Paediatric hospital liaison in progress for Charlie Company personnel.',
    timestamp: '15m ago',
    read: false,
    type: 'urgent',
    linkTarget: 'INT-2026-104',
  },
  {
    id: 'notif-2',
    title: 'Weekly Participation Digest Ready',
    message: '142 Bn completed 91.4% check-in participation for the current cycle.',
    timestamp: '2h ago',
    read: false,
    type: 'update',
  },
  {
    id: 'notif-3',
    title: 'Pending Follow-up Scheduled',
    message: 'Medical category review scheduled for Bravo Coy outpost personnel tomorrow.',
    timestamp: '1d ago',
    read: true,
    type: 'reminder',
    linkTarget: 'INT-2026-102',
  },
];

export const DEFAULT_SETTINGS: NotificationSettings = {
  newSupportRequests: true,
  interventionUpdates: true,
  followUpReminders: true,
  weeklyWelfareDigest: true,
  smsUrgentAlerts: true,
};

export const DEFAULT_PREFERENCES: DashboardPreferences = {
  theme: 'light',
  defaultReportingPeriod: '30d',
  defaultSubUnit: 'all',
  compactTableMode: false,
  confidentialMasking: true,
};

import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { useApp } from '../../context/AppContext';
import { InterventionCategory, InterventionPriority } from '../../types';
import { LifeBuoy, PlusCircle, CheckCircle2 } from 'lucide-react';

interface NewInterventionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessSelectId?: (id: string) => void;
}

export const NewInterventionModal: React.FC<NewInterventionModalProps> = ({
  isOpen,
  onClose,
  onSuccessSelectId,
}) => {
  const { createIntervention, supportProfessionals, subUnits } = useApp();

  const [category, setCategory] = useState<InterventionCategory>('Family Welfare');
  const [subUnit, setSubUnit] = useState<string>('Alpha Company');
  const [priority, setPriority] = useState<InterventionPriority>('Medium');
  const [summary, setSummary] = useState('');
  const [assignedProfessionalId, setAssignedProfessionalId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!summary.trim()) return;

    setIsSubmitting(true);
    const assignedProf = supportProfessionals.find((p) => p.id === assignedProfessionalId);

    const newId = createIntervention({
      category,
      subUnit,
      priority,
      summary,
      assignedProfessionalId: assignedProf?.id,
      assignedProfessionalName: assignedProf ? `${assignedProf.name} (${assignedProf.role})` : undefined,
    });

    setIsSubmitting(false);
    onClose();
    if (onSuccessSelectId) {
      onSuccessSelectId(newId);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Initiate Administrative Welfare Referral"
      subtitle="Authorized unit leadership coordination entry"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="modal-category" className="block text-xs font-semibold text-slate-700 mb-1">
              Welfare Category <span className="text-rose-500">*</span>
            </label>
            <select
              id="modal-category"
              value={category}
              onChange={(e) => setCategory(e.target.value as InterventionCategory)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:border-teal-600"
            >
              <option value="Family Welfare">Family &amp; Domestic Welfare</option>
              <option value="Counselling Support">Counselling &amp; Stress Care</option>
              <option value="Medical Liaison">Medical Liaison &amp; Rehabilitation</option>
              <option value="Personal Assistance">Personal &amp; Legal Assistance</option>
              <option value="Administrative Support">Administrative &amp; Pension Grants</option>
              <option value="Post-Deployment Reintegration">Post-Deployment Reintegration</option>
            </select>
          </div>

          <div>
            <label htmlFor="modal-subunit" className="block text-xs font-semibold text-slate-700 mb-1">
              Target Sub-Unit / Company <span className="text-rose-500">*</span>
            </label>
            <select
              id="modal-subunit"
              value={subUnit}
              onChange={(e) => setSubUnit(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:border-teal-600"
            >
              {subUnits.map((su) => (
                <option key={su.id} value={su.name}>
                  {su.name} ({su.location.split(',')[0]})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="modal-priority" className="block text-xs font-semibold text-slate-700 mb-1">
              Support Priority <span className="text-rose-500">*</span>
            </label>
            <select
              id="modal-priority"
              value={priority}
              onChange={(e) => setPriority(e.target.value as InterventionPriority)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:border-teal-600"
            >
              <option value="Low">Low - Routine Coordination</option>
              <option value="Medium">Medium - Active Liaison Needed</option>
              <option value="High">High - Timely Escalation Required</option>
              <option value="Urgent">Urgent - Immediate Welfare Attention</option>
            </select>
          </div>

          <div>
            <label htmlFor="modal-prof" className="block text-xs font-semibold text-slate-700 mb-1">
              Assign Professional (Optional)
            </label>
            <select
              id="modal-prof"
              value={assignedProfessionalId}
              onChange={(e) => setAssignedProfessionalId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:border-teal-600"
            >
              <option value="">Unassigned (Route to Welfare Cell)</option>
              {supportProfessionals.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} — {p.role}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="modal-summary" className="block text-xs font-semibold text-slate-700 mb-1">
            Operational Summary &amp; Scope of Support <span className="text-rose-500">*</span>
          </label>
          <textarea
            id="modal-summary"
            required
            rows={3}
            placeholder="Describe the operational support required (e.g. Liaison for emergency travel grant, medical specialist appointment, or dependent scholarship)..."
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:border-teal-600"
          />
          <p className="text-[11px] text-slate-500 mt-1">
            * Note: In accordance with VeerSetu privacy charter, do not record personal emotional or psychological diagnoses.
          </p>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 border border-slate-300 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            id="submit-new-case-btn"
            type="submit"
            disabled={isSubmitting || !summary.trim()}
            className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs disabled:opacity-50"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Initiate Referral</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};

import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { CheckCircle2, ShieldCheck } from 'lucide-react';

interface ResolveCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  caseId: string;
  onConfirm: (resolutionSummary: string) => void;
}

export const ResolveCaseModal: React.FC<ResolveCaseModalProps> = ({
  isOpen,
  onClose,
  caseId,
  onConfirm,
}) => {
  const [resolution, setResolution] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resolution.trim()) return;
    onConfirm(resolution);
    setResolution('');
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Conclude Case ${caseId}`}
      subtitle="Finalize operational welfare resolution"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 leading-relaxed">
          Marking this intervention as <strong>Completed</strong> records that all medical, logistical, or administrative actions have been satisfactorily delivered.
        </div>

        <div>
          <label htmlFor="resolution-notes" className="block text-xs font-semibold text-slate-700 mb-1">
            Resolution Summary &amp; Closure Notes <span className="text-rose-500">*</span>
          </label>
          <textarea
            id="resolution-notes"
            required
            rows={3}
            value={resolution}
            onChange={(e) => setResolution(e.target.value)}
            placeholder="Document outcomes (e.g. Dependent hospital admission completed; official leave approved; pension paperwork dispatched)..."
            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:border-emerald-600"
          />
        </div>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 border border-slate-300 rounded-lg"
          >
            Cancel
          </button>
          <button
            id="confirm-resolution-btn"
            type="submit"
            disabled={!resolution.trim()}
            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Mark Concluded</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};

import React from 'react';
import { Modal } from '../common/Modal';
import { VeerSetuLogo } from '../common/VeerSetuLogo';
import { ShieldCheck, EyeOff, Lock, HeartHandshake, CheckCircle2 } from 'lucide-react';

interface PrivacyNoticeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyNoticeModal: React.FC<PrivacyNoticeModalProps> = ({ isOpen, onClose }) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="VeerSetu Ethical Charter & Personnel Privacy Architecture"
      subtitle="Strict Separation of Operational Support from Surveillance & Monitoring"
      maxWidth="2xl"
    >
      <div className="space-y-5 text-sm text-slate-700 dark:text-slate-300">
        <div className="p-3.5 rounded-lg bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-start gap-3.5">
          <VeerSetuLogo size={36} className="shrink-0 mt-0.5" />
          <div className="text-xs text-emerald-900 dark:text-emerald-300 leading-relaxed">
            <strong className="font-semibold block text-emerald-950 dark:text-emerald-200 mb-0.5">Statutory Welfare Mandate · Ministry of Home Affairs</strong>
            VeerSetu operates under authorized Ministry of Home Affairs guidelines for CAPF welfare. The platform strictly prohibits the collection, computation, or display of punitive performance metrics or individual emotional scores.
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
            <div className="flex items-center gap-2 mb-2 text-rose-700 dark:text-rose-400 font-semibold text-xs uppercase tracking-wider">
              <EyeOff className="w-4 h-4" />
              <span>Strictly Prohibited & Absent</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold">✕</span>
                <span>No individual psychological or stress scorecards</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold">✕</span>
                <span>No personal mood trajectory histories shown to command</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold">✕</span>
                <span>No welfare ranking or comparative peer vulnerability lists</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold">✕</span>
                <span>No link to Annual Performance Appraisal Reports (APAR)</span>
              </li>
            </ul>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
            <div className="flex items-center gap-2 mb-2 text-teal-700 dark:text-teal-400 font-semibold text-xs uppercase tracking-wider">
              <HeartHandshake className="w-4 h-4" />
              <span>Authorized Operational Scope</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                <span>Aggregated unit-level check-in participation rates</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                <span>Anonymized triage of family, medical & administrative requests</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                <span>Assignment of accredited medical & counselling officers</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                <span>Timely scheduling of compassionate leave & emergency grants</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-200 dark:border-slate-800 pt-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Lock className="w-4 h-4 text-slate-400 dark:text-slate-500" />
            <span>256-bit Encrypted Session · Audit Trail Active</span>
          </div>
          <button
            id="acknowledge-privacy-btn"
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-teal-600 dark:hover:bg-teal-500 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </Modal>
  );
};

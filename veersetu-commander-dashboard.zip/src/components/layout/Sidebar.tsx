import React from 'react';
import { useApp, PageRoute } from '../../context/AppContext';
import { VeerSetuLogo } from '../common/VeerSetuLogo';
import {
  LayoutDashboard,
  Users2,
  LifeBuoy,
  Settings,
  LogOut,
  Shield,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';

interface SidebarProps {
  onOpenLogout: () => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onOpenLogout, mobileOpen, setMobileOpen }) => {
  const { currentPage, setCurrentPage, interventions } = useApp();

  const activeInterventionsCount = interventions.filter(
    (i) => i.status !== 'Completed'
  ).length;

  const navItems: { id: PageRoute; label: string; icon: React.ElementType; badge?: number }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'unit-overview',
      label: 'Unit Overview',
      icon: Users2,
    },
    {
      id: 'interventions',
      label: 'Intervention Details',
      icon: LifeBuoy,
      badge: activeInterventionsCount,
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
    },
  ];

  const handleNavClick = (page: PageRoute) => {
    setCurrentPage(page);
    setMobileOpen(false);
  };

  const navContent = (
    <div className="flex h-full flex-col justify-between bg-[#0F172A] text-slate-400 border-r border-slate-800 select-none">
      {/* Top Branding Section */}
      <div>
        <div className="flex items-center justify-between p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            {/* Official VeerSetu Logo */}
            <VeerSetuLogo size={36} className="shadow-md" />
            <div>
              <h1 className="text-white font-semibold text-lg tracking-tight leading-none">
                VeerSetu
              </h1>
              <p className="text-slate-500 text-[10px] mt-1 uppercase tracking-widest font-bold">
                COMMANDER DASHBOARD
              </p>
            </div>
          </div>

          {/* Close button on mobile */}
          <button
            onClick={() => setMobileOpen(false)}
            className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Operational Unit Info Chip */}
        <div className="mx-4 my-4 px-3.5 py-2 rounded-lg bg-slate-800/60 border border-slate-700/60 flex items-center gap-2.5 text-xs">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Authorized Unit</p>
            <p className="text-xs font-semibold text-slate-200 truncate">142 Battalion · CRPF</p>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="px-3 space-y-1" aria-label="Sidebar Navigation">
          <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
            Operations Menu
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;

            return (
              <button
                key={item.id}
                id={`sidebar-nav-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`w-full group flex items-center justify-between px-4 py-3 rounded-lg text-xs transition-colors text-left ${
                  isActive
                    ? 'bg-slate-800 text-teal-400 font-medium'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800 font-medium'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-colors ${
                      isActive ? 'text-teal-400' : 'text-slate-400 group-hover:text-white'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge !== undefined && item.badge > 0 ? (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isActive
                        ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                        : 'bg-slate-700 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                ) : (
                  <ChevronRight
                    className={`w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity ${
                      isActive ? 'opacity-100 text-teal-400/80' : 'text-slate-600'
                    }`}
                  />
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Section: Privacy & Sign Out */}
      <div className="p-4 border-t border-slate-800 space-y-3">
        {/* Discretion & Ethics Banner */}
        <div className="px-3.5 py-2.5 rounded-lg bg-slate-900/90 border border-slate-800/80 text-[11px] text-slate-400 leading-relaxed">
          <p className="font-bold text-slate-300 text-xs">Dignity Protocol</p>
          <p className="text-[10px] text-slate-400 mt-0.5">
            Unit aggregated metrics · Strict non-surveillance boundary
          </p>
        </div>

        <button
          id="sidebar-logout-btn"
          onClick={() => {
            setMobileOpen(false);
            onOpenLogout();
          }}
          className="flex items-center gap-3 w-full px-4 py-3 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800/50 transition-colors text-xs font-medium"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          <span>Sign Out Session</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:flex w-64 flex-col fixed inset-y-0 left-0 z-40 border-r border-slate-800/80">
        {navContent}
      </aside>

      {/* Mobile Drawer Backdrop & Sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            onClick={() => setMobileOpen(false)}
          />
          <div className="fixed inset-y-0 left-0 w-72 max-w-full shadow-2xl z-50">
            {navContent}
          </div>
        </div>
      )}
    </>
  );
};

import React from 'react';
import { Modal } from '../common/Modal';
import { LogOut, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface LogoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LogoutModal: React.FC<LogoutModalProps> = ({ isOpen, onClose }) => {
  const { logout } = useApp();

  const handleConfirmLogout = () => {
    onClose();
    logout();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Confirm Commander Portal Sign Out"
      subtitle="Terminate authorized operational session"
      maxWidth="sm"
    >
      <div className="space-y-4 text-sm text-slate-700 dark:text-slate-300">
        <div className="flex items-start gap-3 p-3 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60">
          <AlertCircle className="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5" />
          <p className="text-xs text-amber-900 dark:text-amber-300 leading-relaxed">
            Signing out will conclude your authorized session for 142 Battalion command console. Any unsaved drafts will be securely cleared.
          </p>
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            id="cancel-logout-btn"
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            id="confirm-logout-btn"
            type="button"
            onClick={handleConfirmLogout}
            className="px-4 py-2 bg-rose-600 text-white rounded-lg text-xs font-semibold hover:bg-rose-700 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Confirm Sign Out</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};

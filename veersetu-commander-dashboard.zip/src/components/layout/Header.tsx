import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Bell, 
  ShieldCheck, 
  User, 
  Settings, 
  LogOut, 
  Check, 
  ChevronDown, 
  Building2
} from 'lucide-react';

interface HeaderProps {
  onOpenLogout: () => void;
  onToggleSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenLogout }) => {
  const { 
    currentUser, 
    currentPage, 
    setCurrentPage, 
    notifications, 
    markNotificationRead, 
    markAllNotificationsRead,
    setPrivacyModalOpen,
    setSelectedInterventionId
  } = useApp();

  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);

  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setProfileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getPageTitle = () => {
    switch (currentPage) {
      case 'dashboard':
        return 'Commander Dashboard';
      case 'unit-overview':
        return 'Unit Welfare Overview';
      case 'interventions':
        return 'Intervention Details & Management';
      case 'settings':
        return 'Command Console Settings';
      default:
        return 'VeerSetu Command';
    }
  };

  const handleNotificationClick = (linkTarget?: string, notifId?: string) => {
    if (notifId) markNotificationRead(notifId);
    if (linkTarget) {
      setSelectedInterventionId(linkTarget);
      setCurrentPage('interventions');
    }
    setNotificationsOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0F172A] px-4 md:px-8 transition-colors">
      {/* Left side: Page Title & Unit Identifier */}
      <div className="flex items-center gap-3 md:gap-5 min-w-0">
        <div>
          <h2 className="text-slate-400 dark:text-slate-500 text-xs font-bold uppercase tracking-wider">
            Unit Identification
          </h2>
          <p className="text-slate-900 dark:text-white font-semibold text-sm sm:text-base truncate">
            {getPageTitle()} · 142 BN, CRPF (HQ Sector)
          </p>
        </div>
      </div>

      {/* Right side: Privacy Indicator, Theme Toggle, Notifications, Profile */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* System Secure / Privacy Dignity Shield Pill */}
        <button
          id="privacy-charter-btn"
          onClick={() => setPrivacyModalOpen(true)}
          className="flex items-center gap-2 px-3 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 text-xs font-semibold rounded-full border border-emerald-100 dark:border-emerald-800/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors"
          title="Click to view VeerSetu Personnel Privacy & Dignity Charter"
        >
          <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
          <span className="hidden sm:inline">System Secure · Non-Surveillance</span>
          <span className="sm:hidden">Secure</span>
        </button>

        {/* Notifications Dropdown */}
        <div className="relative" ref={notifRef}>
          <button
            id="notifications-toggle-btn"
            onClick={() => setNotificationsOpen(!notificationsOpen)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 relative transition-colors focus:outline-hidden"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-[10px] flex items-center justify-center rounded-full border-2 border-white dark:border-slate-900 font-bold">
                {unreadCount}
              </span>
            )}
          </button>

          {notificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">Unit Alerts</span>
                  {unreadCount > 0 && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 border border-rose-100 dark:border-rose-800/60">
                      {unreadCount} new
                    </span>
                  )}
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={markAllNotificationsRead}
                    className="text-xs text-teal-600 dark:text-teal-400 hover:text-teal-800 dark:hover:text-teal-300 flex items-center gap-1 font-semibold"
                  >
                    <Check className="w-3 h-3" />
                    <span>Mark all read</span>
                  </button>
                )}
              </div>

              <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                {notifications.map((n) => (
                  <div
                    key={n.id}
                    onClick={() => handleNotificationClick(n.linkTarget, n.id)}
                    className={`px-4 py-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors flex items-start gap-3 ${
                      !n.read ? 'bg-teal-50/30 dark:bg-teal-950/20' : ''
                    }`}
                  >
                    <div
                      className={`mt-1.5 h-2 w-2 rounded-full shrink-0 ${
                        !n.read ? (n.type === 'urgent' ? 'bg-rose-500' : 'bg-teal-500') : 'bg-slate-300 dark:bg-slate-600'
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <p className={`text-xs font-semibold truncate ${!n.read ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-300'}`}>
                          {n.title}
                        </p>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 shrink-0">{n.timestamp}</span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-snug line-clamp-2">
                        {n.message}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 text-center bg-slate-50/70 dark:bg-slate-850">
                <button
                  onClick={() => {
                    setNotificationsOpen(false);
                    setCurrentPage('unit-overview');
                  }}
                  className="text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-400"
                >
                  View full unit activity log →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Profile / Avatar Menu */}
        <div className="relative" ref={profileRef}>
          <button
            id="profile-menu-toggle-btn"
            onClick={() => setProfileMenuOpen(!profileMenuOpen)}
            className="flex items-center gap-2 pl-2 pr-1 py-1 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors focus:outline-hidden"
          >
            <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 border-2 border-white dark:border-slate-800 shadow-xs flex items-center justify-center font-bold text-xs text-slate-700 dark:text-slate-200">
              VR
            </div>
            <div className="text-left hidden sm:block">
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200 leading-tight">
                {currentUser ? currentUser.name.split(' ')[0] : 'Commander'}
              </p>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-wider font-semibold leading-tight">
                {currentUser?.rank || 'Commandant'}
              </p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
          </button>

          {profileMenuOpen && (
            <div className="absolute right-0 mt-2 w-56 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="px-4 py-2.5 border-b border-slate-100 dark:border-slate-800">
                <p className="text-xs font-bold text-slate-900 dark:text-white">{currentUser?.name}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">{currentUser?.email}</p>
                <div className="mt-1.5 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-700 dark:text-slate-300">
                  <span>ID:</span>
                  <span className="font-mono">{currentUser?.serviceId}</span>
                </div>
              </div>

              <div className="py-1">
                <button
                  id="header-goto-settings-btn"
                  onClick={() => {
                    setProfileMenuOpen(false);
                    setCurrentPage('settings');
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left"
                >
                  <Settings className="w-3.5 h-3.5 text-slate-500" />
                  <span>Account &amp; Security Settings</span>
                </button>
                <button
                  id="header-open-privacy-btn"
                  onClick={() => {
                    setProfileMenuOpen(false);
                    setPrivacyModalOpen(true);
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Privacy Charter</span>
                </button>
              </div>

              <div className="border-t border-slate-100 dark:border-slate-800 pt-1">
                <button
                  id="header-logout-btn"
                  onClick={() => {
                    setProfileMenuOpen(false);
                    onOpenLogout();
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors text-left"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

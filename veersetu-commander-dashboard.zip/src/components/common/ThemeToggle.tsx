import React from 'react';
import { Sun, Moon, Monitor } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ThemeMode } from '../../types';

interface ThemeToggleProps {
  variant?: 'pill' | 'segmented' | 'icon' | 'login-bar';
  className?: string;
  showLabels?: boolean;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({
  variant = 'icon',
  className = '',
  showLabels = false,
}) => {
  const { theme, effectiveTheme, setTheme, toggleTheme } = useApp();

  if (variant === 'segmented') {
    const options: { mode: ThemeMode; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
      { mode: 'light', label: 'Light', icon: Sun },
      { mode: 'dark', label: 'Dark', icon: Moon },
      { mode: 'system', label: 'System', icon: Monitor },
    ];

    return (
      <div
        id="theme-segmented-toggle"
        className={`inline-flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 transition-colors ${className}`}
        role="group"
        aria-label="Theme selection"
      >
        {options.map((opt) => {
          const Icon = opt.icon;
          const isActive = theme === opt.mode;
          return (
            <button
              key={opt.mode}
              id={`theme-btn-${opt.mode}`}
              type="button"
              onClick={() => setTheme(opt.mode)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                isActive
                  ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs border border-slate-200/60 dark:border-slate-700'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-700/40'
              }`}
              title={`Switch to ${opt.label} mode`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{opt.label}</span>
            </button>
          );
        })}
      </div>
    );
  }

  if (variant === 'login-bar') {
    return (
      <div
        id="theme-login-bar"
        className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800/60 dark:bg-slate-800 border border-slate-700/60 dark:border-slate-700 text-xs backdrop-blur-xs ${className}`}
      >
        <span className="text-[11px] font-medium text-slate-300 dark:text-slate-400 mr-1 hidden sm:inline">Theme:</span>
        <button
          id="login-theme-light-btn"
          type="button"
          onClick={() => setTheme('light')}
          className={`p-1.5 rounded-md flex items-center gap-1 transition-all ${
            theme === 'light'
              ? 'bg-white text-slate-900 shadow-xs font-semibold'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
          }`}
          title="Light Theme"
        >
          <Sun className="w-3.5 h-3.5" />
          <span className="text-[11px] pr-0.5">Light</span>
        </button>
        <button
          id="login-theme-dark-btn"
          type="button"
          onClick={() => setTheme('dark')}
          className={`p-1.5 rounded-md flex items-center gap-1 transition-all ${
            theme === 'dark'
              ? 'bg-slate-900 text-teal-400 shadow-xs border border-slate-700 font-semibold'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
          }`}
          title="Dark Theme"
        >
          <Moon className="w-3.5 h-3.5" />
          <span className="text-[11px] pr-0.5">Dark</span>
        </button>
      </div>
    );
  }

  if (variant === 'pill') {
    return (
      <button
        id="theme-pill-toggle-btn"
        type="button"
        onClick={toggleTheme}
        className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-semibold transition-all ${
          effectiveTheme === 'dark'
            ? 'bg-slate-800/90 text-amber-300 border-slate-700 hover:bg-slate-700'
            : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
        } ${className}`}
        title={`Current theme: ${effectiveTheme}. Click to toggle.`}
        aria-label="Toggle dark and light theme"
      >
        {effectiveTheme === 'dark' ? (
          <>
            <Sun className="w-3.5 h-3.5 text-amber-400" />
            <span>Light Mode</span>
          </>
        ) : (
          <>
            <Moon className="w-3.5 h-3.5 text-slate-700" />
            <span>Dark Mode</span>
          </>
        )}
      </button>
    );
  }

  // Default 'icon' button
  return (
    <button
      id="theme-icon-toggle-btn"
      type="button"
      onClick={toggleTheme}
      className={`p-2 rounded-lg transition-colors border ${
        effectiveTheme === 'dark'
          ? 'bg-slate-800 text-amber-300 border-slate-700 hover:bg-slate-700 hover:text-amber-200'
          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
      } ${className}`}
      title={`Switch to ${effectiveTheme === 'dark' ? 'Light' : 'Dark'} Mode`}
      aria-label="Toggle theme"
    >
      {effectiveTheme === 'dark' ? (
        <Sun className="w-4 h-4 transition-transform hover:rotate-45" />
      ) : (
        <Moon className="w-4 h-4 transition-transform hover:-rotate-12" />
      )}
      {showLabels && (
        <span className="ml-2 text-xs font-medium">
          {effectiveTheme === 'dark' ? 'Light Mode' : 'Dark Mode'}
        </span>
      )}
    </button>
  );
};

import React from 'react';

interface VeerSetuLogoProps {
  size?: number | string;
  className?: string;
  withSquircle?: boolean;
}

export const VeerSetuLogo: React.FC<VeerSetuLogoProps> = ({
  size = 32,
  className = '',
  withSquircle = true,
}) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={`shrink-0 select-none ${className}`}
      aria-label="VeerSetu Official Emblem"
    >
      <defs>
        {/* Tactical Squircle Dark Slate Background */}
        <linearGradient id="vs-logo-bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#1B231F" />
          <stop offset="50%" stopColor="#141A17" />
          <stop offset="100%" stopColor="#0D1210" />
        </linearGradient>

        {/* Soft Bevel Rim */}
        <linearGradient id="vs-logo-rim" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#3E4E43" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#1A221D" stopOpacity="0.3" />
        </linearGradient>

        {/* Left Arm: Warm Ivory Bone */}
        <linearGradient id="vs-logo-ivory" x1="0%" y1="0%" x2="80%" y2="100%">
          <stop offset="0%" stopColor="#FAF8F4" />
          <stop offset="70%" stopColor="#ECE6DB" />
          <stop offset="100%" stopColor="#DED7C8" />
        </linearGradient>

        {/* Right Arm: CAPF Tactical Olive Green */}
        <linearGradient id="vs-logo-olive" x1="20%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#869C69" />
          <stop offset="50%" stopColor="#738658" />
          <stop offset="100%" stopColor="#5E6F46" />
        </linearGradient>

        {/* Lower Tip: Deep Forest Green */}
        <linearGradient id="vs-logo-forest" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3A4E32" />
          <stop offset="100%" stopColor="#22331D" />
        </linearGradient>

        {/* Dynamic Bridge Swoop: Bright Saffron Gold */}
        <linearGradient id="vs-logo-gold" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#F5A429" />
          <stop offset="50%" stopColor="#F9BC45" />
          <stop offset="100%" stopColor="#FDD36E" />
        </linearGradient>

        {/* Lower Bridge Layer: Warm Saffron Ochre */}
        <linearGradient id="vs-logo-saffron" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#C36611" />
          <stop offset="50%" stopColor="#DB7B1A" />
          <stop offset="100%" stopColor="#EC9127" />
        </linearGradient>
      </defs>

      {/* Outer Tactical Squircle Container */}
      {withSquircle && (
        <>
          <rect x="2" y="2" width="96" height="96" rx="23" ry="23" fill="url(#vs-logo-bg)" />
          <rect
            x="2.5"
            y="2.5"
            width="95"
            height="95"
            rx="22.5"
            ry="22.5"
            fill="none"
            stroke="url(#vs-logo-rim)"
            strokeWidth="1"
          />
        </>
      )}

      {/* Central "V" & Bridge ("Setu") Geometry */}
      <g transform={withSquircle ? undefined : 'scale(1.15) translate(-6.5, -6.5)'}>
        {/* 1. Left Wing (Ivory White) */}
        <path
          d="M 25 35
             H 36.5
             L 48.2 52.6
             L 43.5 58.2
             Z"
          fill="url(#vs-logo-ivory)"
        />

        {/* 2. Right Wing (Olive Green) */}
        <path
          d="M 63.5 35
             H 75
             L 69.5 48.5
             C 64.5 48.2, 57.5 49.5, 51.5 53.5
             Z"
          fill="url(#vs-logo-olive)"
        />

        {/* 3. Lower Wedge (Deep Forest Green) */}
        <path
          d="M 43.5 58.2
             C 46 62, 48 66, 50 71
             L 59 55.5
             C 54 57.5, 48 58.5, 43.5 58.2
             Z"
          fill="url(#vs-logo-forest)"
        />

        {/* 4. Lower Saffron Ribbon (Bridge Foundation) */}
        <path
          d="M 43.5 58.2
             C 48 58.5, 54 57.5, 59 55.5
             C 55 53.5, 49 54, 44 56.5
             Z"
          fill="url(#vs-logo-saffron)"
        />

        {/* 5. Upper Golden Ribbon (Bridge / Setu Arc) */}
        <path
          d="M 43.5 57.2
             C 48.5 51, 57 47.5, 69.5 48.5
             C 62 49.8, 53 53.2, 44.5 60
             Z"
          fill="url(#vs-logo-gold)"
        />
      </g>
    </svg>
  );
};

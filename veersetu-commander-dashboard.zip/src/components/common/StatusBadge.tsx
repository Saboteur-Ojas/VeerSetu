import React from 'react';
import { InterventionStatus, InterventionPriority } from '../../types';

interface StatusBadgeProps {
  status: InterventionStatus;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-0.5 text-[11px]';

  switch (status) {
    case 'Created':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 font-bold ${sizeClasses}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span>
          <span>Created</span>
        </span>
      );
    case 'Assigned':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-blue-50 text-blue-700 border border-blue-100 font-bold ${sizeClasses}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
          <span>Assigned</span>
        </span>
      );
    case 'In Progress':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-amber-50 text-amber-700 border border-amber-100 font-bold ${sizeClasses}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
          <span>In Progress</span>
        </span>
      );
    case 'Follow-up':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-teal-50 text-teal-700 border border-teal-100 font-bold ${sizeClasses}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-teal-600"></span>
          <span>Follow-up</span>
        </span>
      );
    case 'Completed':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100 font-bold ${sizeClasses}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
          <span>Completed</span>
        </span>
      );
    default:
      return <span className={`inline-flex items-center rounded-full bg-slate-100 text-slate-700 font-bold ${sizeClasses}`}>{status}</span>;
  }
};

interface PriorityBadgeProps {
  priority: InterventionPriority | 'Operational' | 'Moderate';
  size?: 'sm' | 'md';
}

export const PriorityBadge: React.FC<PriorityBadgeProps> = ({ priority, size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-0.5 text-[11px]';

  switch (priority) {
    case 'Urgent':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-rose-50 text-rose-700 border border-rose-100 font-bold ${sizeClasses}`}>
          <span className="text-rose-500">▲</span>
          <span>Urgent</span>
        </span>
      );
    case 'High':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-orange-50 text-orange-700 border border-orange-100 font-bold ${sizeClasses}`}>
          <span className="text-orange-500">▲</span>
          <span>High</span>
        </span>
      );
    case 'Moderate':
    case 'Medium':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-amber-50 text-amber-700 border border-amber-100 font-bold ${sizeClasses}`}>
          <span className="text-amber-500">■</span>
          <span>{priority === 'Moderate' ? 'Moderate' : 'Medium'}</span>
        </span>
      );
    case 'Low':
    case 'Operational':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-slate-100 text-slate-600 border border-slate-200 font-bold ${sizeClasses}`}>
          <span className="text-slate-400">●</span>
          <span>{priority}</span>
        </span>
      );
    default:
      return <span className={`inline-flex items-center rounded-full bg-slate-100 text-slate-700 font-bold ${sizeClasses}`}>{priority}</span>;
  }
};

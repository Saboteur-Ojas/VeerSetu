import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { DashboardPage } from './pages/DashboardPage';
import { UnitOverviewPage } from './pages/UnitOverviewPage';
import { InterventionsPage } from './pages/InterventionsPage';
import { SettingsPage } from './pages/SettingsPage';
import { LoginPage } from './pages/LoginPage';
import { ToastContainer } from './components/common/Toast';
import { PrivacyNoticeModal } from './components/layout/PrivacyNoticeModal';
import { LogoutModal } from './components/layout/LogoutModal';
import { VeerSetuLogo } from './components/common/VeerSetuLogo';
import { Menu } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { currentPage, isAuthenticated, privacyModalOpen, setPrivacyModalOpen } = useApp();
  const [logoutModalOpen, setLogoutModalOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // If not logged in or on login/register page, show Login screen
  if (!isAuthenticated || currentPage === 'login' || currentPage === 'register') {
    return (
      <>
        <LoginPage />
        <ToastContainer />
      </>
    );
  }

  const renderActivePage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'unit-overview':
        return <UnitOverviewPage />;
      case 'interventions':
        return <InterventionsPage />;
      case 'settings':
        return <SettingsPage onOpenLogout={() => setLogoutModalOpen(true)} />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#0B1120] flex text-[#1E293B] dark:text-[#E2E8F0] selection:bg-teal-600 selection:text-white font-sans transition-colors duration-200">
      {/* Left Sidebar */}
      <Sidebar
        onOpenLogout={() => setLogoutModalOpen(true)}
        mobileOpen={mobileSidebarOpen}
        setMobileOpen={setMobileSidebarOpen}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col md:pl-64 min-w-0 transition-all min-h-screen justify-between">
        <div className="flex-1 flex flex-col">
          {/* Mobile Header Menu Trigger Bar */}
          <div className="md:hidden flex items-center justify-between px-4 py-3 bg-[#0F172A] text-white border-b border-slate-800">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-200 hover:text-white"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <VeerSetuLogo size={26} />
              <span className="font-semibold text-sm tracking-tight text-white">
                VeerSetu
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-teal-400 border border-slate-700">
                Command
              </span>
            </div>
            <div className="text-[11px] font-mono text-slate-400">142 Bn</div>
          </div>

          {/* Top Header */}
          <Header
            onOpenLogout={() => setLogoutModalOpen(true)}
            onToggleSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          />

          {/* Page Content Body */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
            {renderActivePage()}
          </main>
        </div>

        {/* Clean Utility Minimal Footer */}
        <footer className="h-12 bg-white dark:bg-[#0F172A] border-t border-slate-200 dark:border-slate-800 px-6 sm:px-8 flex items-center justify-between shrink-0 transition-colors">
          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium truncate mr-4">
            VeerSetu © 2026 · Security Protocol 14-B Active · Privacy-first Interface
          </p>
          <div className="flex items-center gap-4 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest shrink-0">
            <button
              onClick={() => setPrivacyModalOpen(true)}
              className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors"
            >
              Audit Log
            </button>
            <button
              onClick={() => setPrivacyModalOpen(true)}
              className="hover:text-teal-600 transition-colors"
            >
              Support
            </button>
          </div>
        </footer>
      </div>

      {/* Global Modals & Toasts */}
      <ToastContainer />
      <PrivacyNoticeModal
        isOpen={privacyModalOpen}
        onClose={() => setPrivacyModalOpen(false)}
      />
      <LogoutModal
        isOpen={logoutModalOpen}
        onClose={() => setLogoutModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}

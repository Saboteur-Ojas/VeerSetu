import React, { useState } from 'react';
import { AppProvider, useApp, PageRoute } from './context/AppContext';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { DashboardPage } from './pages/DashboardPage';
import { UnitOverviewPage } from './pages/UnitOverviewPage';
import { InterventionsPage } from './pages/InterventionsPage';
import { SettingsPage } from './pages/SettingsPage';
import { LoginPage } from './pages/LoginPage';
import { ToastContainer } from './components/common/Toast';
import { PrivacyNoticeModal } from './components/layout/PrivacyNoticeModal';
import { LogoutModal } from './components/layout/LogoutModal';
import { 
  LayoutDashboard, 
  Users2, 
  LifeBuoy, 
  Settings 
} from 'lucide-react';

const MainLayout: React.FC = () => {
  const { currentPage, setCurrentPage, interventions, isAuthenticated, privacyModalOpen, setPrivacyModalOpen } = useApp();
  const [logoutModalOpen, setLogoutModalOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // If not logged in or on login/register page, show Login screen
  if (!isAuthenticated || currentPage === 'login' || currentPage === 'register') {
    return (
      <>
        <LoginPage />
        <ToastContainer />
      </>
    );
  }

  const activeInterventionsCount = interventions.filter(
    (i) => i.status !== 'Completed'
  ).length;

  const mobileNavItems: { id: PageRoute; label: string; icon: React.ElementType; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'unit-overview', label: 'Unit', icon: Users2 },
    { id: 'interventions', label: 'Cases', icon: LifeBuoy, badge: activeInterventionsCount },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const renderActivePage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'unit-overview':
        return <UnitOverviewPage />;
      case 'interventions':
        return <InterventionsPage />;
      case 'settings':
        return <SettingsPage onOpenLogout={() => setLogoutModalOpen(true)} />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#0B1120] flex text-[#1E293B] dark:text-[#E2E8F0] selection:bg-teal-600 selection:text-white font-sans transition-colors duration-200">
      {/* Left Sidebar (Desktop persistent, mobile slide-over drawer) */}
      <Sidebar
        onOpenLogout={() => setLogoutModalOpen(true)}
        mobileOpen={mobileSidebarOpen}
        setMobileOpen={setMobileSidebarOpen}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col md:pl-64 min-w-0 transition-all min-h-screen justify-between">
        <div className="flex-1 flex flex-col min-w-0">
          {/* Top Unified Responsive Header */}
          <Header
            onOpenLogout={() => setLogoutModalOpen(true)}
            onToggleSidebar={() => setMobileSidebarOpen(true)}
          />

          {/* Page Content Body (with bottom safe padding on mobile for bottom nav) */}
          <main className="flex-1 p-3 sm:p-5 lg:p-8 overflow-y-auto pb-24 md:pb-8 min-w-0">
            {renderActivePage()}
          </main>
        </div>

        {/* Clean Utility Minimal Footer (desktop/tablet) */}
        <footer className="hidden md:flex h-12 bg-white dark:bg-[#0F172A] border-t border-slate-200 dark:border-slate-800 px-6 sm:px-8 items-center justify-between shrink-0 transition-colors">
          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium truncate mr-4">
            VeerSetu © 2026 · Security Protocol 14-B Active · Privacy-first Interface
          </p>
          <div className="flex items-center gap-4 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest shrink-0">
            <button
              onClick={() => setPrivacyModalOpen(true)}
              className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors"
            >
              Audit Log
            </button>
            <button
              onClick={() => setPrivacyModalOpen(true)}
              className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors"
            >
              Support
            </button>
          </div>
        </footer>
      </div>

      {/* Mobile Bottom Navigation Bar for Instant One-Thumb Switching */}
      <nav 
        className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-[#0F172A]/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 py-1.5 px-3 flex items-center justify-around shadow-xl transition-colors"
        aria-label="Mobile Bottom Navigation"
      >
        {mobileNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-lg text-[10px] font-semibold transition-all relative ${
                isActive
                  ? 'text-teal-600 dark:text-teal-400'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1 -right-2 px-1 min-w-3.5 h-3.5 rounded-full text-[9px] font-bold bg-teal-600 text-white flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="mt-0.5">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Global Modals & Toasts */}
      <ToastContainer />
      <PrivacyNoticeModal
        isOpen={privacyModalOpen}
        onClose={() => setPrivacyModalOpen(false)}
      />
      <LogoutModal
        isOpen={logoutModalOpen}
        onClose={() => setLogoutModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}

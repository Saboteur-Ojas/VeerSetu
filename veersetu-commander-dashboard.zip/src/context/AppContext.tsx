import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  Intervention,
  InterventionStatus,
  InterventionPriority,
  InterventionCategory,
  SubUnitData,
  NotificationItem,
  NotificationSettings,
  DashboardPreferences,
  SupportProfessional,
  ThemeMode,
} from '../types';
import {
  INITIAL_USER,
  INITIAL_INTERVENTIONS,
  SUB_UNITS_DATA,
  SUPPORT_PROFESSIONALS,
  DEFAULT_NOTIFICATIONS,
  DEFAULT_SETTINGS,
  DEFAULT_PREFERENCES,
} from '../data/mockData';

export type PageRoute = 'dashboard' | 'unit-overview' | 'interventions' | 'settings' | 'login' | 'register';

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

interface AppContextType {
  currentUser: UserProfile | null;
  isAuthenticated: boolean;
  currentPage: PageRoute;
  setCurrentPage: (page: PageRoute) => void;
  interventions: Intervention[];
  subUnits: SubUnitData[];
  supportProfessionals: SupportProfessional[];
  selectedInterventionId: string | null;
  setSelectedInterventionId: (id: string | null) => void;
  selectedSubUnitFilter: string;
  setSelectedSubUnitFilter: (subUnit: string) => void;
  selectedTimeframe: '7d' | '30d' | '90d' | 'all';
  setSelectedTimeframe: (tf: '7d' | '30d' | '90d' | 'all') => void;
  notifications: NotificationItem[];
  notificationSettings: NotificationSettings;
  preferences: DashboardPreferences;
  toasts: ToastMessage[];
  login: (serviceIdOrEmail: string, password?: string) => boolean;
  register: (profile: Partial<UserProfile>) => boolean;
  logout: () => void;
  updateInterventionStatus: (id: string, status: InterventionStatus, noteContent?: string) => void;
  assignProfessional: (id: string, professionalId: string, professionalName: string) => void;
  addInterventionNote: (id: string, content: string, authorRole?: string) => void;
  markInterventionComplete: (id: string, resolutionSummary: string) => void;
  setFollowUpDate: (id: string, date: string) => void;
  createIntervention: (data: {
    category: InterventionCategory;
    subUnit: string;
    priority: InterventionPriority;
    summary: string;
    assignedProfessionalId?: string;
    assignedProfessionalName?: string;
  }) => string;
  updateUserProfile: (profile: Partial<UserProfile>) => void;
  updateNotificationSettings: (settings: Partial<NotificationSettings>) => void;
  updatePreferences: (prefs: Partial<DashboardPreferences>) => void;
  dismissToast: (id: string) => void;
  showToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  privacyModalOpen: boolean;
  setPrivacyModalOpen: (open: boolean) => void;
  theme: ThemeMode;
  effectiveTheme: 'light' | 'dark';
  setTheme: (theme: ThemeMode) => void;
  toggleTheme: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load saved state or default
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('veersetu_user');
    if (saved) {
      try { return JSON.parse(saved); } catch { return INITIAL_USER; }
    }
    return INITIAL_USER; // Default logged in as Commander for instant functional evaluation
  });

  const [currentPage, setCurrentPage] = useState<PageRoute>(() => {
    const savedUser = localStorage.getItem('veersetu_user');
    return savedUser ? 'dashboard' : 'dashboard';
  });

  const [interventions, setInterventions] = useState<Intervention[]>(() => {
    const saved = localStorage.getItem('veersetu_interventions');
    if (saved) {
      try { return JSON.parse(saved); } catch { return INITIAL_INTERVENTIONS; }
    }
    return INITIAL_INTERVENTIONS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('veersetu_notifications');
    if (saved) {
      try { return JSON.parse(saved); } catch { return DEFAULT_NOTIFICATIONS; }
    }
    return DEFAULT_NOTIFICATIONS;
  });

  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>(() => {
    const saved = localStorage.getItem('veersetu_notif_settings');
    if (saved) {
      try { return JSON.parse(saved); } catch { return DEFAULT_SETTINGS; }
    }
    return DEFAULT_SETTINGS;
  });

  const [preferences, setPreferences] = useState<DashboardPreferences>(() => {
    const saved = localStorage.getItem('veersetu_preferences');
    if (saved) {
      try { return JSON.parse(saved); } catch { return DEFAULT_PREFERENCES; }
    }
    return DEFAULT_PREFERENCES;
  });

  const [theme, setThemeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('veersetu_theme');
    if (saved === 'light' || saved === 'dark' || saved === 'system') {
      return saved as ThemeMode;
    }
    const savedPrefs = localStorage.getItem('veersetu_preferences');
    if (savedPrefs) {
      try {
        const parsed = JSON.parse(savedPrefs);
        if (parsed.theme) return parsed.theme;
      } catch {}
    }
    return 'light';
  });

  const [systemIsDark, setSystemIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemIsDark(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  const effectiveTheme: 'light' | 'dark' = theme === 'system' ? (systemIsDark ? 'dark' : 'light') : theme;

  useEffect(() => {
    localStorage.setItem('veersetu_theme', theme);
    if (effectiveTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme, effectiveTheme]);

  const setTheme = (newTheme: ThemeMode) => {
    setThemeState(newTheme);
    setPreferences((prev) => ({ ...prev, theme: newTheme }));
  };

  const toggleTheme = () => {
    setTheme(effectiveTheme === 'dark' ? 'light' : 'dark');
  };

  const [selectedInterventionId, setSelectedInterventionId] = useState<string | null>(null);
  const [selectedSubUnitFilter, setSelectedSubUnitFilter] = useState<string>('all');
  const [selectedTimeframe, setSelectedTimeframe] = useState<'7d' | '30d' | '90d' | 'all'>('30d');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [privacyModalOpen, setPrivacyModalOpen] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('veersetu_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('veersetu_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('veersetu_interventions', JSON.stringify(interventions));
  }, [interventions]);

  useEffect(() => {
    localStorage.setItem('veersetu_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('veersetu_notif_settings', JSON.stringify(notificationSettings));
  }, [notificationSettings]);

  useEffect(() => {
    localStorage.setItem('veersetu_preferences', JSON.stringify(preferences));
  }, [preferences]);

  const showToast = (title: string, description?: string, type: 'success' | 'info' | 'warning' | 'error' = 'success') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const login = (serviceIdOrEmail: string, _password?: string): boolean => {
    const user: UserProfile = {
      ...INITIAL_USER,
      serviceId: serviceIdOrEmail.includes('@') ? 'CAPF-782190' : serviceIdOrEmail,
      email: serviceIdOrEmail.includes('@') ? serviceIdOrEmail : 'commandant.142bn@capf.gov.in',
    };
    setCurrentUser(user);
    setCurrentPage('dashboard');
    showToast('Secure Session Established', `Welcome Commandant Rathore. Authenticated for 142 Bn command oversight.`, 'success');
    return true;
  };

  const register = (profile: Partial<UserProfile>): boolean => {
    const newUser: UserProfile = {
      id: `usr-${Date.now()}`,
      name: profile.name || 'Commandant User',
      serviceId: profile.serviceId || 'CAPF-NEW',
      email: profile.email || 'officer@capf.gov.in',
      phone: profile.phone || '+91 98000 00000',
      rank: 'Commandant',
      unit: '142 Battalion, BSF · Sector Jammu',
      role: 'Commandant',
      twoFactorEnabled: true,
    };
    setCurrentUser(newUser);
    showToast('Account Created Successfully', 'Your authorized commander credentials have been registered.', 'success');
    return true;
  };

  const logout = () => {
    setCurrentUser(null);
    setCurrentPage('login');
    showToast('Session Terminated', 'You have been securely logged out of the VeerSetu Commander Portal.', 'info');
  };

  const updateInterventionStatus = (id: string, status: InterventionStatus, noteContent?: string) => {
    setInterventions((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const updatedNotes = [...item.notes];
          if (noteContent) {
            updatedNotes.unshift({
              id: `note-${Date.now()}`,
              timestamp: new Date().toISOString(),
              authorName: currentUser?.name || 'Commandant V. S. Rathore',
              authorRole: currentUser?.role || 'Commandant',
              content: noteContent,
            });
          }
          return {
            ...item,
            status,
            updatedAt: new Date().toISOString(),
            notes: updatedNotes,
          };
        }
        return item;
      })
    );
    showToast('Status Updated', `Case ${id} status advanced to ${status}.`, 'success');
  };

  const assignProfessional = (id: string, professionalId: string, professionalName: string) => {
    setInterventions((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const updatedNotes = [
            {
              id: `note-${Date.now()}`,
              timestamp: new Date().toISOString(),
              authorName: currentUser?.name || 'Commandant V. S. Rathore',
              authorRole: 'Commandant',
              content: `Support professional assigned: ${professionalName}. Operational clearance granted.`,
            },
            ...item.notes,
          ];
          return {
            ...item,
            assignedProfessionalId: professionalId,
            assignedProfessionalName: professionalName,
            status: item.status === 'Created' ? 'Assigned' : item.status,
            updatedAt: new Date().toISOString(),
            notes: updatedNotes,
          };
        }
        return item;
      })
    );
    showToast('Professional Assigned', `${professionalName} has been assigned to coordinate case ${id}.`, 'info');
  };

  const addInterventionNote = (id: string, content: string, authorRole: string = 'Commandant') => {
    setInterventions((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newNote = {
            id: `note-${Date.now()}`,
            timestamp: new Date().toISOString(),
            authorName: currentUser?.name || 'Commandant V. S. Rathore',
            authorRole,
            content,
          };
          return {
            ...item,
            updatedAt: new Date().toISOString(),
            notes: [newNote, ...item.notes],
          };
        }
        return item;
      })
    );
    showToast('Note Appended', `Operational welfare note logged for case ${id}.`, 'success');
  };

  const markInterventionComplete = (id: string, resolutionSummary: string) => {
    setInterventions((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const finalNote = {
            id: `note-${Date.now()}`,
            timestamp: new Date().toISOString(),
            authorName: currentUser?.name || 'Commandant V. S. Rathore',
            authorRole: 'Commandant',
            content: `Case formally concluded. Resolution: ${resolutionSummary}`,
          };
          return {
            ...item,
            status: 'Completed',
            resolutionSummary,
            updatedAt: new Date().toISOString(),
            notes: [finalNote, ...item.notes],
          };
        }
        return item;
      })
    );
    showToast('Intervention Concluded', `Case ${id} marked as Completed with resolution documentation.`, 'success');
  };

  const setFollowUpDate = (id: string, date: string) => {
    setInterventions((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            nextFollowUpDate: date,
            updatedAt: new Date().toISOString(),
          };
        }
        return item;
      })
    );
    showToast('Follow-Up Scheduled', `Follow-up date for ${id} set to ${date}.`, 'info');
  };

  const createIntervention = (data: {
    category: InterventionCategory;
    subUnit: string;
    priority: InterventionPriority;
    summary: string;
    assignedProfessionalId?: string;
    assignedProfessionalName?: string;
  }): string => {
    const newId = `INT-2026-${Math.floor(110 + Math.random() * 80)}`;
    const newIntervention: Intervention = {
      id: newId,
      category: data.category,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: data.assignedProfessionalId ? 'Assigned' : 'Created',
      priority: data.priority,
      subUnit: data.subUnit,
      summary: data.summary,
      assignedProfessionalId: data.assignedProfessionalId,
      assignedProfessionalName: data.assignedProfessionalName,
      notes: [
        {
          id: `note-${Date.now()}`,
          timestamp: new Date().toISOString(),
          authorName: currentUser?.name || 'Commandant V. S. Rathore',
          authorRole: currentUser?.role || 'Commandant',
          content: `Intervention initiated by unit leadership. Category: ${data.category}. Priority: ${data.priority}.`,
        }
      ]
    };

    setInterventions((prev) => [newIntervention, ...prev]);
    showToast('Support Case Initiated', `Intervention ${newId} created successfully.`, 'success');
    return newId;
  };

  const updateUserProfile = (profile: Partial<UserProfile>) => {
    if (!currentUser) return;
    setCurrentUser((prev) => prev ? { ...prev, ...profile } : null);
    showToast('Profile Updated', 'Your commander credentials and contact info have been saved.', 'success');
  };

  const updateNotificationSettings = (settings: Partial<NotificationSettings>) => {
    setNotificationSettings((prev) => ({ ...prev, ...settings }));
    showToast('Preferences Saved', 'Notification thresholds updated immediately.', 'info');
  };

  const updatePreferences = (prefs: Partial<DashboardPreferences>) => {
    setPreferences((prev) => ({ ...prev, ...prefs }));
    showToast('View Preferences Applied', 'Dashboard display settings updated.', 'info');
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast('Notifications Cleared', 'All alerts marked as reviewed.', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        currentPage,
        setCurrentPage,
        interventions,
        subUnits: SUB_UNITS_DATA,
        supportProfessionals: SUPPORT_PROFESSIONALS,
        selectedInterventionId,
        setSelectedInterventionId,
        selectedSubUnitFilter,
        setSelectedSubUnitFilter,
        selectedTimeframe,
        setSelectedTimeframe,
        notifications,
        notificationSettings,
        preferences,
        toasts,
        login,
        register,
        logout,
        updateInterventionStatus,
        assignProfessional,
        addInterventionNote,
        markInterventionComplete,
        setFollowUpDate,
        createIntervention,
        updateUserProfile,
        updateNotificationSettings,
        updatePreferences,
        dismissToast,
        showToast,
        markNotificationRead,
        markAllNotificationsRead,
        privacyModalOpen,
        setPrivacyModalOpen,
        theme,
        effectiveTheme,
        setTheme,
        toggleTheme,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Shield, 
  Lock, 
  Mail, 
  User, 
  Phone, 
  CheckCircle2, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  ArrowRight,
  Building2,
  FileCheck2
} from 'lucide-react';
import { Modal } from '../components/common/Modal';
import { VeerSetuLogo } from '../components/common/VeerSetuLogo';

export const LoginPage: React.FC = () => {
  const { login, register, showToast } = useApp();

  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('CAPF-782190');
  const [loginPassword, setLoginPassword] = useState('VeerSetu@Command2026');
  const [rememberSession, setRememberSession] = useState(true);
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Register form state
  const [regFullName, setRegFullName] = useState('');
  const [regServiceId, setRegServiceId] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regConfirmedAccurate, setRegConfirmedAccurate] = useState(false);
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [regErrors, setRegErrors] = useState<Record<string, string>>({});
  const [isRegistering, setIsRegistering] = useState(false);
  const [registerSuccessModal, setRegisterSuccessModal] = useState(false);

  // Forgot password modal state
  const [forgotPasswordModal, setForgotPasswordModal] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState(false);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    if (!loginIdentifier.trim()) {
      setLoginError('Please enter your Service ID or Official Email Address.');
      return;
    }
    if (!loginPassword.trim()) {
      setLoginError('Please enter your authorization password.');
      return;
    }

    setIsLoggingIn(true);
    setTimeout(() => {
      setIsLoggingIn(false);
      login(loginIdentifier, loginPassword);
    }, 600);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};

    if (!regFullName.trim()) errors.fullName = 'Full Name is required.';
    if (!regServiceId.trim()) errors.serviceId = 'Official Service ID is required (e.g. CAPF-XXXXXX).';
    if (!regEmail.trim()) {
      errors.email = 'Official Email Address is required.';
    } else if (!regEmail.includes('@') || !regEmail.includes('.')) {
      errors.email = 'Please provide a valid official email format.';
    }
    if (!regPhone.trim()) errors.phone = 'Contact number is required.';
    if (!regPassword) {
      errors.password = 'Password is required.';
    } else if (regPassword.length < 8) {
      errors.password = 'Password must be at least 8 characters.';
    }
    if (regPassword !== regConfirmPassword) {
      errors.confirmPassword = 'Passwords do not match.';
    }
    if (!regConfirmedAccurate) {
      errors.accurate = 'You must certify the accuracy of your authorized appointment.';
    }

    setRegErrors(errors);

    if (Object.keys(errors).length === 0) {
      setIsRegistering(true);
      setTimeout(() => {
        setIsRegistering(false);
        setRegisterSuccessModal(true);
      }, 700);
    }
  };

  const handleCompleteRegistration = () => {
    setRegisterSuccessModal(false);
    register({
      name: regFullName,
      serviceId: regServiceId,
      email: regEmail,
      phone: regPhone,
    });
  };

  const handleFillDemo = () => {
    setLoginIdentifier('CAPF-782190');
    setLoginPassword('VeerSetu@Command2026');
    showToast('Demo Credentials Loaded', 'Commandant V. S. Rathore, 142 Bn CAPF pre-filled.', 'info');
  };

  const handleForgotPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail || !forgotEmail.includes('@')) {
      showToast('Validation Error', 'Please input a valid official email address.', 'error');
      return;
    }
    setForgotSuccess(true);
    setTimeout(() => {
      setForgotSuccess(false);
      setForgotPasswordModal(false);
      setForgotEmail('');
      showToast('Recovery Dispatched', 'Password reset instructions transmitted via encrypted Gov NIC mail.', 'info');
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-slate-900 text-slate-100 selection:bg-teal-600 selection:text-white">
      {/* Top Security Banner */}
      <div className="w-full bg-[#070D18] border-b border-slate-800/90 py-2 px-4 text-center">
        <div className="flex items-center justify-center gap-2 text-[11px] font-mono uppercase tracking-widest text-slate-400">
          <Shield className="w-3.5 h-3.5 text-teal-400" />
          <span>Government of India · Ministry of Home Affairs · CAPF Welfare Architecture</span>
        </div>
      </div>

      {/* Main Authentication Container */}
      <div className="flex-1 flex items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
        <div className="w-full max-w-md space-y-7">
          {/* VeerSetu Branding Card Header */}
          <div className="text-center space-y-3">
            <div className="inline-flex items-center justify-center p-1 rounded-2xl shadow-xl">
              <VeerSetuLogo size={72} className="shadow-lg shadow-black/40" />
            </div>
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight text-white font-['Plus_Jakarta_Sans']">
                VeerSetu
              </h1>
              <p className="text-xs font-semibold uppercase tracking-wider text-teal-400">
                Commander Portal · Authorized Operational Access
              </p>
            </div>
            <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
              Personnel Welfare Coordination &amp; Dignified Support Management for Unit Leadership
            </p>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="bg-slate-800/80 p-1 rounded-xl border border-slate-700/80 flex">
            <button
              id="tab-login"
              type="button"
              onClick={() => {
                setActiveTab('login');
                setLoginError(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all duration-150 ${
                activeTab === 'login'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Commander Sign In
            </button>
            <button
              id="tab-register"
              type="button"
              onClick={() => {
                setActiveTab('register');
                setRegErrors({});
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all duration-150 ${
                activeTab === 'register'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Register Commander
            </button>
          </div>

          {/* Authentication Card */}
          <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-6 sm:p-7 shadow-2xl backdrop-blur-md">
            {activeTab === 'login' ? (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                {loginError && (
                  <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{loginError}</span>
                  </div>
                )}

                <div>
                  <label htmlFor="login-identifier" className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Official Email or Service ID <span className="text-rose-400">*</span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      id="login-identifier"
                      type="text"
                      required
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      placeholder="e.g. CAPF-782190 or officer@capf.gov.in"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-hidden focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label htmlFor="login-password" className="block text-xs font-semibold text-slate-300">
                      Authorization Password <span className="text-rose-400">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setForgotPasswordModal(true)}
                      className="text-xs text-teal-400 hover:text-teal-300 transition-colors"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id="login-password"
                      type={showLoginPassword ? 'text' : 'password'}
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-hidden focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPassword(!showLoginPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200"
                      aria-label="Toggle password visibility"
                    >
                      {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      id="remember-session"
                      type="checkbox"
                      checked={rememberSession}
                      onChange={(e) => setRememberSession(e.target.checked)}
                      className="w-4 h-4 rounded bg-slate-900 border-slate-700 text-teal-600 focus:ring-teal-500 focus:ring-offset-slate-900"
                    />
                    <span className="text-xs text-slate-300">Remember authorized session</span>
                  </label>

                  <button
                    type="button"
                    onClick={handleFillDemo}
                    className="text-[11px] text-amber-400 hover:text-amber-300 underline underline-offset-2"
                  >
                    Quick Demo Credentials
                  </button>
                </div>

                <div className="pt-2">
                  <button
                    id="submit-login-btn"
                    type="submit"
                    disabled={isLoggingIn}
                    className="w-full py-2.5 px-4 rounded-lg bg-teal-600 hover:bg-teal-500 active:bg-teal-700 text-white text-xs sm:text-sm font-bold shadow-lg shadow-teal-900/50 flex items-center justify-center gap-2 transition-all disabled:opacity-60"
                  >
                    {isLoggingIn ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"></div>
                        <span>Authenticating Credentials...</span>
                      </>
                    ) : (
                      <>
                        <span>Access Commander Dashboard</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            ) : (
              /* Register Form */
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                <div>
                  <label htmlFor="reg-fullname" className="block text-xs font-semibold text-slate-300 mb-1">
                    Full Name &amp; Rank <span className="text-rose-400">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="reg-fullname"
                      type="text"
                      placeholder="e.g. Commandant Vikramjit S. Rathore"
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      className={`w-full px-3 py-2 bg-slate-900/80 border rounded-lg text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-hidden ${
                        regErrors.fullName ? 'border-rose-500' : 'border-slate-700 focus:border-teal-500'
                      }`}
                    />
                  </div>
                  {regErrors.fullName && <p className="text-[11px] text-rose-400 mt-1">{regErrors.fullName}</p>}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="reg-serviceid" className="block text-xs font-semibold text-slate-300 mb-1">
                      Service ID <span className="text-rose-400">*</span>
                    </label>
                    <input
                      id="reg-serviceid"
                      type="text"
                      placeholder="CAPF-782190"
                      value={regServiceId}
                      onChange={(e) => setRegServiceId(e.target.value)}
                      className={`w-full px-3 py-2 bg-slate-900/80 border rounded-lg text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-hidden ${
                        regErrors.serviceId ? 'border-rose-500' : 'border-slate-700 focus:border-teal-500'
                      }`}
                    />
                    {regErrors.serviceId && <p className="text-[11px] text-rose-400 mt-1">{regErrors.serviceId}</p>}
                  </div>

                  <div>
                    <label htmlFor="reg-phone" className="block text-xs font-semibold text-slate-300 mb-1">
                      Phone Number <span className="text-rose-400">*</span>
                    </label>
                    <input
                      id="reg-phone"
                      type="tel"
                      placeholder="+91 94191 XXXXX"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      className={`w-full px-3 py-2 bg-slate-900/80 border rounded-lg text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-hidden ${
                        regErrors.phone ? 'border-rose-500' : 'border-slate-700 focus:border-teal-500'
                      }`}
                    />
                    {regErrors.phone && <p className="text-[11px] text-rose-400 mt-1">{regErrors.phone}</p>}
                  </div>
                </div>

                <div>
                  <label htmlFor="reg-email" className="block text-xs font-semibold text-slate-300 mb-1">
                    Official Email Address (.gov.in / .nic.in) <span className="text-rose-400">*</span>
                  </label>
                  <input
                    id="reg-email"
                    type="email"
                    placeholder="officer.142bn@capf.gov.in"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className={`w-full px-3 py-2 bg-slate-900/80 border rounded-lg text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-hidden ${
                      regErrors.email ? 'border-rose-500' : 'border-slate-700 focus:border-teal-500'
                    }`}
                  />
                  {regErrors.email && <p className="text-[11px] text-rose-400 mt-1">{regErrors.email}</p>}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="reg-password" className="block text-xs font-semibold text-slate-300 mb-1">
                      Password <span className="text-rose-400">*</span>
                    </label>
                    <div className="relative">
                      <input
                        id="reg-password"
                        type={showRegPassword ? 'text' : 'password'}
                        placeholder="Min 8 characters"
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        className={`w-full px-3 pr-8 py-2 bg-slate-900/80 border rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-hidden ${
                          regErrors.password ? 'border-rose-500' : 'border-slate-700 focus:border-teal-500'
                        }`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowRegPassword(!showRegPassword)}
                        className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400"
                      >
                        {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    {regErrors.password && <p className="text-[11px] text-rose-400 mt-1">{regErrors.password}</p>}
                  </div>

                  <div>
                    <label htmlFor="reg-confirm-password" className="block text-xs font-semibold text-slate-300 mb-1">
                      Confirm Password <span className="text-rose-400">*</span>
                    </label>
                    <input
                      id="reg-confirm-password"
                      type={showRegPassword ? 'text' : 'password'}
                      placeholder="Re-enter password"
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      className={`w-full px-3 py-2 bg-slate-900/80 border rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-hidden ${
                        regErrors.confirmPassword ? 'border-rose-500' : 'border-slate-700 focus:border-teal-500'
                      }`}
                    />
                    {regErrors.confirmPassword && (
                      <p className="text-[11px] text-rose-400 mt-1">{regErrors.confirmPassword}</p>
                    )}
                  </div>
                </div>

                <div className="pt-1">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      id="confirm-accurate-checkbox"
                      type="checkbox"
                      checked={regConfirmedAccurate}
                      onChange={(e) => setRegConfirmedAccurate(e.target.checked)}
                      className="mt-0.5 w-4 h-4 rounded bg-slate-900 border-slate-700 text-teal-600 focus:ring-teal-500"
                    />
                    <span className="text-xs text-slate-300 leading-snug">
                      I confirm that the information provided is accurate and I am authorized unit leadership under CAPF Service Regulations.
                    </span>
                  </label>
                  {regErrors.accurate && <p className="text-[11px] text-rose-400 mt-1">{regErrors.accurate}</p>}
                </div>

                <div className="pt-2">
                  <button
                    id="submit-register-btn"
                    type="submit"
                    disabled={isRegistering}
                    className="w-full py-2.5 px-4 rounded-lg bg-teal-600 hover:bg-teal-500 active:bg-teal-700 text-white text-xs sm:text-sm font-bold shadow-lg shadow-teal-900/50 flex items-center justify-center gap-2 transition-all disabled:opacity-60"
                  >
                    {isRegistering ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"></div>
                        <span>Verifying Authorization...</span>
                      </>
                    ) : (
                      <>
                        <FileCheck2 className="w-4 h-4" />
                        <span>Create Account</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Privacy Footnote */}
          <div className="text-center text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-slate-500" />
            <span>Encrypted Session · Strict Ethical Non-Surveillance Architecture</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="w-full bg-[#070D18] border-t border-slate-800/90 py-3 px-4 text-center text-xs text-slate-500">
        <p>© 2026 VeerSetu Platform. For Authorized CAPF Leadership Use Only.</p>
      </footer>

      {/* Register Success Modal */}
      <Modal
        isOpen={registerSuccessModal}
        onClose={handleCompleteRegistration}
        title="Commander Credentials Registered"
        subtitle="Verification against central welfare ledger approved"
        maxWidth="sm"
      >
        <div className="space-y-4 text-center py-2">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
            <CheckCircle2 className="w-7 h-7" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900">Welcome, {regFullName}</h4>
            <p className="text-xs text-slate-600 mt-1">
              Your service profile <span className="font-mono font-semibold">{regServiceId}</span> has been provisioned with 142 Bn Commander privileges.
            </p>
          </div>
          <button
            id="modal-goto-dashboard-btn"
            onClick={handleCompleteRegistration}
            className="w-full py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-colors"
          >
            Enter Commander Dashboard
          </button>
        </div>
      </Modal>

      {/* Forgot Password Modal */}
      <Modal
        isOpen={forgotPasswordModal}
        onClose={() => setForgotPasswordModal(false)}
        title="Commander Credential Recovery"
        subtitle="Secure identity verification for unit leadership"
        maxWidth="sm"
      >
        <form onSubmit={handleForgotPasswordSubmit} className="space-y-4 py-1">
          <p className="text-xs text-slate-600 leading-relaxed">
            Enter your registered official email or Service ID. An OTP recovery dispatch will be routed through the secure NIC Gov gateway.
          </p>
          <div>
            <label htmlFor="forgot-email" className="block text-xs font-medium text-slate-700 mb-1">
              Official Email Address
            </label>
            <input
              id="forgot-email"
              type="email"
              required
              value={forgotEmail}
              onChange={(e) => setForgotEmail(e.target.value)}
              placeholder="officer.142bn@capf.gov.in"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:border-teal-600"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setForgotPasswordModal(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              id="submit-forgot-btn"
              type="submit"
              disabled={forgotSuccess}
              className="px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5"
            >
              {forgotSuccess ? 'Sending OTP...' : 'Send Recovery Link'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

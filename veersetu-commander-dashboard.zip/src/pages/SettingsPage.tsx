import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  User, 
  Bell, 
  ShieldCheck, 
  Sliders, 
  LogOut, 
  Key, 
  Smartphone, 
  Laptop, 
  Check, 
  AlertCircle,
  Save,
  Lock,
  Download
} from 'lucide-react';
import { Modal } from '../components/common/Modal';
import { ThemeToggle } from '../components/common/ThemeToggle';

interface SettingsPageProps {
  onOpenLogout: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onOpenLogout }) => {
  const { 
    currentUser, 
    updateUserProfile, 
    notificationSettings, 
    updateNotificationSettings, 
    preferences, 
    updatePreferences,
    showToast,
    setPrivacyModalOpen
  } = useApp();

  // Account form state
  const [name, setName] = useState(currentUser?.name || '');
  const [serviceId, setServiceId] = useState(currentUser?.serviceId || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [isSavingAccount, setIsSavingAccount] = useState(false);

  // Security password modal
  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);

  // Two-factor state
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(currentUser?.twoFactorEnabled ?? true);

  // Sessions mock
  const [sessions, setSessions] = useState([
    {
      id: 'sess-1',
      device: 'Command PC · Windows Workstation (NIC LAN)',
      ip: '10.142.18.4',
      location: 'Sector HQ Jammu Operations Wing',
      current: true,
      lastActive: 'Active Now',
    },
    {
      id: 'sess-2',
      device: 'Encrypted Tablet · Android Secure EMM',
      ip: '10.142.22.9',
      location: 'Forward Command Vehicle',
      current: false,
      lastActive: '3 hours ago',
    }
  ]);

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingAccount(true);
    setTimeout(() => {
      updateUserProfile({
        name,
        serviceId,
        email,
        phone,
      });
      setIsSavingAccount(false);
    }, 400);
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);

    if (!currentPassword) {
      setPasswordError('Please enter your current authorization password.');
      return;
    }
    if (newPassword.length < 8) {
      setPasswordError('New password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match.');
      return;
    }

    setPasswordModalOpen(false);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    showToast('Security Updated', 'Commander authorization password rotated successfully.', 'success');
  };

  const handleRevokeSession = (sessionId: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== sessionId));
    showToast('Session Revoked', 'The device session has been terminated.', 'info');
  };

  const handleExportAuditReport = () => {
    showToast('Report Generated', '142 Bn Welfare Summary & Intervention Audit compiled into official dispatch.', 'success');
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div className="pb-3 border-b border-slate-200">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">
          Command Console Settings &amp; Security
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Configure leadership credentials, notification alerts, two-factor authentication, and unit preferences
        </p>
      </div>

      {/* SECTION 1: ACCOUNT INFORMATION */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 sm:p-6">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
          <div className="p-2 rounded-lg bg-teal-50 text-teal-700">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">Commander Account Profile</h3>
            <p className="text-xs text-slate-500">Official identity and service contact channels</p>
          </div>
        </div>

        <form onSubmit={handleSaveAccount} className="space-y-4 mt-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="settings-name" className="block text-xs font-semibold text-slate-700 mb-1">
                Full Name &amp; Designation
              </label>
              <input
                id="settings-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-teal-600 font-medium"
              />
            </div>

            <div>
              <label htmlFor="settings-serviceid" className="block text-xs font-semibold text-slate-700 mb-1">
                Official Service ID
              </label>
              <input
                id="settings-serviceid"
                type="text"
                value={serviceId}
                onChange={(e) => setServiceId(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-teal-600 font-mono font-semibold"
              />
            </div>

            <div>
              <label htmlFor="settings-email" className="block text-xs font-semibold text-slate-700 mb-1">
                Official Email (Government NIC)
              </label>
              <input
                id="settings-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-teal-600"
              />
            </div>

            <div>
              <label htmlFor="settings-phone" className="block text-xs font-semibold text-slate-700 mb-1">
                Official Duty Phone
              </label>
              <input
                id="settings-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-teal-600"
              />
            </div>
          </div>

          <div className="flex items-center justify-end pt-3">
            <button
              id="save-account-btn"
              type="submit"
              disabled={isSavingAccount}
              className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSavingAccount ? 'Saving...' : 'Save Profile Changes'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* SECTION 2: NOTIFICATIONS */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 sm:p-6">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
          <div className="p-2 rounded-lg bg-teal-50 text-teal-700">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">Unit Support Notification Controls</h3>
            <p className="text-xs text-slate-500">Configure alert channels and operational thresholds</p>
          </div>
        </div>

        <div className="divide-y divide-slate-100 mt-3">
          <div className="py-3 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-800">New Support Inquiries</p>
              <p className="text-[11px] text-slate-500">Alert when a new intake request is routed to battalion triage</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notificationSettings.newSupportRequests}
                onChange={(e) => updateNotificationSettings({ newSupportRequests: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-600"></div>
            </label>
          </div>

          <div className="py-3 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-800">Intervention Updates &amp; Notes</p>
              <p className="text-[11px] text-slate-500">Notify upon progress updates added by medical and welfare staff</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notificationSettings.interventionUpdates}
                onChange={(e) => updateNotificationSettings({ interventionUpdates: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-600"></div>
            </label>
          </div>

          <div className="py-3 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-800">Follow-up Reminders</p>
              <p className="text-[11px] text-slate-500">Prompt scheduled check-in dates for pending compassionate cases</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notificationSettings.followUpReminders}
                onChange={(e) => updateNotificationSettings({ followUpReminders: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-600"></div>
            </label>
          </div>

          <div className="py-3 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-800">Weekly Aggregated Welfare Digest</p>
              <p className="text-[11px] text-slate-500">Consolidated statistical email dispatched every Monday morning</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notificationSettings.weeklyWelfareDigest}
                onChange={(e) => updateNotificationSettings({ weeklyWelfareDigest: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-600"></div>
            </label>
          </div>
        </div>
      </div>

      {/* SECTION 3: SECURITY & SESSIONS */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 sm:p-6">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
          <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">Security &amp; Session Management</h3>
            <p className="text-xs text-slate-500">Access authorization controls and authorized workstations</p>
          </div>
        </div>

        <div className="space-y-4 mt-5">
          {/* Password Action */}
          <div className="flex items-center justify-between p-3.5 rounded-lg border border-slate-200 bg-slate-50/50">
            <div>
              <p className="text-xs font-bold text-slate-900">Commander Authorization Password</p>
              <p className="text-[11px] text-slate-500">Last rotated 32 days ago · Mandatory 90-day rotation cycle</p>
            </div>
            <button
              id="open-change-password-btn"
              onClick={() => setPasswordModalOpen(true)}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold transition-colors"
            >
              Rotate Password
            </button>
          </div>

          {/* Two-Factor Authentication */}
          <div className="flex items-center justify-between p-3.5 rounded-lg border border-slate-200 bg-slate-50/50">
            <div>
              <p className="text-xs font-bold text-slate-900">Two-Factor Authentication (2FA)</p>
              <p className="text-[11px] text-slate-500">Enforced via Central Gov NIC Authenticator / SMS Gateway</p>
            </div>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
              <Check className="w-3.5 h-3.5" />
              <span>Enforced (Active)</span>
            </span>
          </div>

          {/* Active Sessions */}
          <div>
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Active Authorized Workstation Sessions
            </h4>
            <div className="space-y-2">
              {sessions.map((sess) => (
                <div
                  key={sess.id}
                  className="flex items-center justify-between p-3 rounded-lg border border-slate-200 bg-white"
                >
                  <div className="flex items-center gap-3">
                    <Laptop className="w-4 h-4 text-slate-400" />
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-bold text-slate-800">{sess.device}</p>
                        {sess.current && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-50 text-teal-800 border border-teal-200">
                            Current Machine
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        {sess.location} · IP: <span className="font-mono">{sess.ip}</span>
                      </p>
                    </div>
                  </div>

                  {!sess.current && (
                    <button
                      onClick={() => handleRevokeSession(sess.id)}
                      className="text-xs text-rose-600 hover:text-rose-800 font-semibold"
                    >
                      Revoke
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 4: DASHBOARD PREFERENCES & AUDIT EXPORT */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 sm:p-6">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
          <div className="p-2 rounded-lg bg-teal-50 text-teal-700">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">Dashboard Operational Preferences</h3>
            <p className="text-xs text-slate-500">Default reporting periods and unit view configurations</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5">
          <div>
            <label htmlFor="pref-period" className="block text-xs font-semibold text-slate-700 mb-1">
              Default Reporting Period
            </label>
            <select
              id="pref-period"
              value={preferences.defaultReportingPeriod}
              onChange={(e) => updatePreferences({ defaultReportingPeriod: e.target.value as any })}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 bg-slate-50 focus:outline-hidden focus:border-teal-600"
            >
              <option value="7d">Last 7 Days (Fortnightly)</option>
              <option value="30d">Last 30 Days (Monthly)</option>
              <option value="90d">Current Quarter (Q3 FY26)</option>
            </select>
          </div>

          <div>
            <label htmlFor="pref-coy" className="block text-xs font-semibold text-slate-700 mb-1">
              Default Primary Sub-Unit
            </label>
            <select
              id="pref-coy"
              value={preferences.defaultSubUnit}
              onChange={(e) => updatePreferences({ defaultSubUnit: e.target.value })}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 bg-slate-50 focus:outline-hidden focus:border-teal-600"
            >
              <option value="all">All Companies (Battalion Level)</option>
              <option value="HQ Company">HQ Company</option>
              <option value="Alpha Company">Alpha Company</option>
              <option value="Bravo Company">Bravo Company</option>
              <option value="Charlie Company">Charlie Company</option>
              <option value="Delta Company">Delta Company</option>
            </select>
          </div>
        </div>

        {/* Visual Theme Mode Selector */}
        <div className="mt-5 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">Interface Visual Theme</h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Toggle between High-Contrast Dark Tactical View and Clean Light View across all commander tools
            </p>
          </div>
          <ThemeToggle variant="segmented" />
        </div>

        <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <button
            onClick={() => setPrivacyModalOpen(true)}
            className="text-xs font-bold text-teal-700 hover:text-teal-900 flex items-center gap-1.5 text-left"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>View VeerSetu Privacy &amp; Ethical Mandate Charter</span>
          </button>

          <button
            id="export-audit-btn"
            onClick={handleExportAuditReport}
            className="px-3.5 py-2 border border-slate-300 hover:bg-slate-100 text-slate-800 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Generate Sector Welfare Report</span>
          </button>
        </div>
      </div>

      {/* SECTION 5: SIGN OUT ACTION */}
      <div className="p-5 rounded-xl border border-rose-200 bg-rose-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-bold text-rose-950">Terminate Commander Session</h4>
          <p className="text-xs text-rose-800 mt-0.5">
            Safely close authorized operational console for 142 Battalion
          </p>
        </div>
        <button
          id="settings-logout-btn"
          onClick={onOpenLogout}
          className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Sign Out Session</span>
        </button>
      </div>

      {/* Change Password Modal */}
      <Modal
        isOpen={passwordModalOpen}
        onClose={() => setPasswordModalOpen(false)}
        title="Rotate Authorization Password"
        subtitle="Enforce CAPF cyber security compliance"
        maxWidth="sm"
      >
        <form onSubmit={handleChangePassword} className="space-y-3.5 py-1">
          {passwordError && (
            <div className="p-2.5 rounded bg-rose-50 text-rose-700 text-xs border border-rose-200 flex items-start gap-1.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{passwordError}</span>
            </div>
          )}

          <div>
            <label htmlFor="current-pw" className="block text-xs font-semibold text-slate-700 mb-1">
              Current Password
            </label>
            <input
              id="current-pw"
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-blue-600"
            />
          </div>

          <div>
            <label htmlFor="new-pw" className="block text-xs font-semibold text-slate-700 mb-1">
              New Password (Min 8 chars)
            </label>
            <input
              id="new-pw"
              type="password"
              required
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-blue-600"
            />
          </div>

          <div>
            <label htmlFor="confirm-new-pw" className="block text-xs font-semibold text-slate-700 mb-1">
              Confirm New Password
            </label>
            <input
              id="confirm-new-pw"
              type="password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-blue-600"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setPasswordModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              id="save-new-password-btn"
              type="submit"
              className="px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-colors"
            >
              Update Password
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

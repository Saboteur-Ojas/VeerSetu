import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Users, 
  CheckCircle2, 
  HelpCircle, 
  LifeBuoy, 
  CheckCheck, 
  Filter, 
  Calendar, 
  Building2, 
  ShieldAlert, 
  ShieldCheck, 
  TrendingUp, 
  Layers,
  Info,
  MapPin,
  UserCheck
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  PieChart, 
  Pie, 
  Cell, 
  Legend, 
  AreaChart, 
  Area 
} from 'recharts';
import { SUB_UNITS_DATA, CATEGORY_BREAKDOWN } from '../data/mockData';

export const UnitOverviewPage: React.FC = () => {
  const { 
    subUnits, 
    interventions, 
    selectedSubUnitFilter, 
    setSelectedSubUnitFilter,
    setPrivacyModalOpen,
    setCurrentPage,
    setSelectedInterventionId
  } = useApp();

  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d'>('30d');
  const [supportCategoryFilter, setSupportCategoryFilter] = useState<string>('all');

  // Filter calculations
  const filteredSubUnits = useMemo(() => {
    if (selectedSubUnitFilter === 'all') return subUnits;
    return subUnits.filter((su) => su.name.toLowerCase().includes(selectedSubUnitFilter.toLowerCase()));
  }, [subUnits, selectedSubUnitFilter]);

  // Aggregate stats based on active sub-unit filter
  const summaryStats = useMemo(() => {
    let personnel = 0;
    let totalRateWeight = 0;
    let activeReqs = 0;
    let ongoingInts = 0;

    filteredSubUnits.forEach((su) => {
      personnel += su.personnelCount;
      totalRateWeight += su.checkInRate * su.personnelCount;
      activeReqs += su.activeRequests;
      ongoingInts += su.ongoingInterventions;
    });

    const avgRate = personnel > 0 ? (totalRateWeight / personnel).toFixed(1) : '0';

    // Count completed in this subUnit
    const completedInts = interventions.filter(i => {
      const matchCoy = selectedSubUnitFilter === 'all' || i.subUnit.toLowerCase().includes(selectedSubUnitFilter.toLowerCase());
      return matchCoy && i.status === 'Completed';
    }).length;

    return {
      personnel,
      checkInRate: `${avgRate}%`,
      activeRequests: activeReqs,
      ongoingInterventions: ongoingInts,
      completedInterventions: completedInts + (selectedSubUnitFilter === 'all' ? 12 : 2), // includes historic resolved cycles
    };
  }, [filteredSubUnits, interventions, selectedSubUnitFilter]);

  // Data for Sub-unit participation comparison chart
  const subUnitComparisonData = useMemo(() => {
    return subUnits.map((su) => ({
      name: su.name.replace(' Company', ' Coy'),
      participation: su.checkInRate,
      personnel: su.personnelCount,
      activeRequests: su.activeRequests,
    }));
  }, [subUnits]);

  // Intervention progress status breakdown
  const statusProgressData = useMemo(() => {
    const relevantInts = interventions.filter(i => {
      return selectedSubUnitFilter === 'all' || i.subUnit.toLowerCase().includes(selectedSubUnitFilter.toLowerCase());
    });

    const counts = {
      Created: 0,
      Assigned: 0,
      'In Progress': 0,
      'Follow-up': 0,
      Completed: 0,
    };

    relevantInts.forEach((i) => {
      if (counts[i.status] !== undefined) {
        counts[i.status] += 1;
      }
    });

    return [
      { status: 'Triage / Created', count: counts['Created'], color: '#94A3B8' },
      { status: 'Assigned', count: counts['Assigned'], color: '#0EA5E9' },
      { status: 'In Progress', count: counts['In Progress'], color: '#F59E0B' },
      { status: 'Follow-up Due', count: counts['Follow-up'], color: '#0D9488' },
      { status: 'Resolved / Concluded', count: counts['Completed'], color: '#10B981' },
    ];
  }, [interventions, selectedSubUnitFilter]);

  const COLORS = ['#0D9488', '#0EA5E9', '#6366F1', '#D97706', '#10B981'];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Filter Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-teal-600" />
            <span className="text-sm font-bold text-slate-900">Unit Operational Filters</span>
            <span className="text-xs text-slate-300">|</span>
            <span className="text-xs text-slate-500">Filters dynamically synchronize aggregated welfare metrics</span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-2.5 sm:gap-3 w-full md:w-auto">
            {/* Sub-unit / Department Selector */}
            <div className="flex items-center gap-1.5 w-full sm:w-auto">
              <label htmlFor="subunit-filter" className="text-xs font-semibold text-slate-600 shrink-0">
                Sub-Unit:
              </label>
              <select
                id="subunit-filter"
                value={selectedSubUnitFilter}
                onChange={(e) => setSelectedSubUnitFilter(e.target.value)}
                className="w-full sm:w-auto text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:outline-hidden focus:border-teal-600"
              >
                <option value="all">All Companies (Battalion Level)</option>
                <option value="HQ Company">HQ Company (RS Pura)</option>
                <option value="Alpha Company">Alpha Company (Suchetgarh)</option>
                <option value="Bravo Company">Bravo Company (Arnia)</option>
                <option value="Charlie Company">Charlie Company (Pargwal)</option>
                <option value="Delta Company">Delta Company (Reserve Base)</option>
              </select>
            </div>

            {/* Reporting Period Filter */}
            <div className="flex items-center gap-1.5 w-full sm:w-auto">
              <label htmlFor="period-filter" className="text-xs font-semibold text-slate-600 shrink-0">
                Period:
              </label>
              <select
                id="period-filter"
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value as any)}
                className="w-full sm:w-auto text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:outline-hidden focus:border-teal-600"
              >
                <option value="7d">Last 7 Days (Fortnight Cycle)</option>
                <option value="30d">Last 30 Days (Monthly Aggregate)</option>
                <option value="90d">Current Quarter (Q3 FY26)</option>
              </select>
            </div>

            {/* Reset / Clear Button */}
            {selectedSubUnitFilter !== 'all' && (
              <button
                onClick={() => setSelectedSubUnitFilter('all')}
                className="text-xs text-teal-600 hover:text-teal-800 font-bold underline self-start sm:self-auto"
              >
                Reset to All
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Unit Summary Metric Cards (5 Cards) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-3.5">
        <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 text-xs font-bold uppercase tracking-wide">Total Strength</span>
            <div className="p-1.5 rounded-lg bg-slate-100 text-slate-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-light mt-1 text-slate-900">{summaryStats.personnel}</div>
          <p className="text-[11px] text-slate-400 mt-2 truncate">Assigned to {selectedSubUnitFilter === 'all' ? '142 Bn' : selectedSubUnitFilter}</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 text-xs font-bold uppercase tracking-wide">Participation</span>
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-light mt-1 text-slate-900">{summaryStats.checkInRate}</div>
          <p className="text-[11px] text-slate-400 mt-2">Check-in completion rate</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 text-xs font-bold uppercase tracking-wide">Active Requests</span>
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-700">
              <HelpCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-light mt-1 text-slate-900">{summaryStats.activeRequests}</div>
          <p className="text-[11px] text-slate-400 mt-2">Welfare inquiries in queue</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 text-xs font-bold uppercase tracking-wide">In Progress</span>
            <div className="p-1.5 rounded-lg bg-teal-50 text-teal-700">
              <LifeBuoy className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-light mt-1 text-slate-900">{summaryStats.ongoingInterventions}</div>
          <p className="text-[11px] text-slate-400 mt-2">Assigned to welfare team</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 text-xs font-bold uppercase tracking-wide">Resolved Cases</span>
            <div className="p-1.5 rounded-lg bg-slate-100 text-slate-600">
              <CheckCheck className="w-4 h-4 text-emerald-600" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-light mt-1 text-slate-900">{summaryStats.completedInterventions}</div>
          <p className="text-[11px] text-slate-400 mt-2">Satisfactorily concluded</p>
        </div>
      </div>

      {/* Sub-Unit Details Cards Grid (When All Companies is selected) */}
      {selectedSubUnitFilter === 'all' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Sub-Unit Deployment &amp; Welfare Overview
              </h3>
              <p className="text-xs text-slate-500">
                Detailed readiness and support status across 142 Battalion company locations
              </p>
            </div>
            <span className="text-xs font-bold text-teal-600 bg-teal-50 px-2.5 py-1 rounded-full border border-teal-100">5 Operational Sub-Units</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
            {subUnits.map((su) => (
              <div
                key={su.id}
                className="p-5 rounded-xl border border-slate-200 hover:border-teal-500 bg-white hover:shadow-sm transition-all"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{su.name}</h4>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>{su.location}</span>
                    </p>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      su.checkInRate >= 90
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-100'
                        : 'bg-amber-50 text-amber-700 border-amber-100'
                    }`}
                  >
                    {su.checkInRate}% Check-in
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 text-center py-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Personnel</span>
                    <span className="text-xs font-bold text-slate-800">{su.personnelCount}</span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Inquiries</span>
                    <span className="text-xs font-bold text-amber-700">{su.activeRequests}</span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Active Cases</span>
                    <span className="text-xs font-bold text-teal-700">{su.ongoingInterventions}</span>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-500 flex items-center gap-1">
                    <UserCheck className="w-3 h-3 text-slate-400" />
                    <span>OIC: {su.commanderInCharge}</span>
                  </span>
                  <button
                    onClick={() => setSelectedSubUnitFilter(su.name)}
                    className="text-xs font-bold text-teal-600 hover:text-teal-800"
                  >
                    Filter Coy →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Aggregated Visualizations: Check-In Participation & Support Demand */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sub-Unit Participation Comparison */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                  Check-in Participation across Sub-Units
                </h3>
                <p className="text-xs text-slate-500">
                  Aggregated completion rates (%) by company detachment
                </p>
              </div>
              <span className="text-xs font-bold text-slate-500">Target: &gt;90%</span>
            </div>

            <div className="h-64 mt-4 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={subUnitComparisonData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#CBD5E1" />
                  <YAxis domain={[75, 100]} tick={{ fontSize: 11, fill: '#64748B' }} stroke="#CBD5E1" unit="%" />
                  <Tooltip
                    formatter={(val: any) => [`${val}% Check-in Rate`, 'Participation']}
                    contentStyle={{
                      backgroundColor: '#0F172A',
                      borderRadius: '8px',
                      color: '#F8FAFC',
                      border: 'none',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="participation" fill="#0D9488" radius={[4, 4, 0, 0]} maxBarSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1">
            <span>High completion rates indicate strong unit operational communication</span>
            <span className="font-semibold text-slate-700">All data anonymized</span>
          </div>
        </div>

        {/* Intervention Status Progression Pipeline */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                  Intervention Progress Pipeline
                </h3>
                <p className="text-xs text-slate-500">
                  Case distribution across operational lifecycle stages
                </p>
              </div>
              <button
                onClick={() => setCurrentPage('interventions')}
                className="text-xs font-bold text-teal-600 hover:text-teal-800"
              >
                Manage All →
              </button>
            </div>

            <div className="h-64 mt-4 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={statusProgressData}
                  layout="vertical"
                  margin={{ top: 10, right: 20, left: 35, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E2E8F0" />
                  <XAxis type="number" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#CBD5E1" />
                  <YAxis
                    type="category"
                    dataKey="status"
                    tick={{ fontSize: 11, fill: '#475569' }}
                    stroke="#CBD5E1"
                    width={90}
                  />
                  <Tooltip
                    formatter={(val: any) => [`${val} Cases`, 'Volume']}
                    contentStyle={{
                      backgroundColor: '#0F172A',
                      borderRadius: '8px',
                      color: '#F8FAFC',
                      border: 'none',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="count" fill="#0EA5E9" radius={[0, 4, 4, 0]} maxBarSize={24} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
            <span>Structured progression ensures zero support requests remain neglected</span>
            <span className="font-semibold text-emerald-700">Audit Compliant</span>
          </div>
        </div>
      </div>

      {/* Intervention Category Distribution Breakdown */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-slate-900 tracking-tight">
              Aggregated Support Demand Breakdown by Category
            </h3>
            <p className="text-xs text-slate-500">
              Categorical distribution of unit welfare requirements across reporting cycle
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-500">Based on 34 total unit inquiries this cycle</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-4 items-center">
          {/* Pie Visualizer */}
          <div className="h-56 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={CATEGORY_BREAKDOWN}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {CATEGORY_BREAKDOWN.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${val}% of inquiries`, 'Demand Share']}
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderRadius: '8px',
                    color: '#F8FAFC',
                    border: 'none',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Accessible Legend & Counts */}
          <div className="lg:col-span-2 space-y-2">
            {CATEGORY_BREAKDOWN.map((item, index) => (
              <div
                key={item.name}
                className="flex items-center justify-between p-2.5 rounded-lg border border-slate-150 hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className="w-3 h-3 rounded-xs shrink-0"
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-800">{item.name}</span>
                    <span className="text-[11px] text-slate-400 ml-2">({item.count} inquiries)</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-24 bg-slate-100 rounded-full h-2 hidden sm:block">
                    <div
                      className="h-2 rounded-full"
                      style={{
                        width: `${item.value}%`,
                        backgroundColor: COLORS[index % COLORS.length],
                      }}
                    />
                  </div>
                  <span className="text-xs font-bold text-slate-900 w-10 text-right">
                    {item.value}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Personnel Privacy Guarantee Banner */}
      <div className="p-5 rounded-xl border border-teal-200 bg-teal-50/50 flex items-start gap-4">
        <ShieldCheck className="w-6 h-6 text-teal-700 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-800 leading-relaxed flex-1">
          <strong className="font-bold block text-sm text-slate-900 mb-1">
            Dignity &amp; Privacy Safeguard Active
          </strong>
          <p className="text-slate-600">
            Under CAPF VeerSetu protocols, personal psychological scores, mood trajectory histories, and emotional survey responses are never surfaced to command leadership. Unit Overview displays only high-level operational categories to coordinate essential logistical, medical, and family support.
          </p>
          <div className="mt-3">
            <button
              onClick={() => setPrivacyModalOpen(true)}
              className="text-xs font-bold text-teal-700 hover:text-teal-900 underline"
            >
              Read full VeerSetu Privacy &amp; Dignity Charter →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

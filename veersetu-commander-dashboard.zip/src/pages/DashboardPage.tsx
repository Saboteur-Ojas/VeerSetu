import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Users, 
  CheckCircle2, 
  HelpCircle, 
  LifeBuoy, 
  TrendingUp, 
  AlertCircle, 
  Clock, 
  ChevronRight, 
  Calendar, 
  Building2, 
  ShieldCheck, 
  Activity,
  ArrowUpRight,
  Filter
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  BarChart, 
  Bar, 
  Legend 
} from 'recharts';
import { PriorityBadge } from '../components/common/StatusBadge';
import { ATTENTION_ITEMS, PARTICIPATION_TRENDS, RECENT_ACTIVITIES } from '../data/mockData';

export const DashboardPage: React.FC = () => {
  const { 
    currentUser, 
    setCurrentPage, 
    setSelectedInterventionId, 
    setSelectedSubUnitFilter, 
    interventions,
    setPrivacyModalOpen
  } = useApp();

  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'quarter'>('week');
  const [activityMetric, setActivityMetric] = useState<'participation' | 'requests'>('participation');

  // Compute greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning, Commander';
    if (hour < 17) return 'Good Afternoon, Commander';
    return 'Good Evening, Commander';
  };

  // Dynamic counts
  const totalPersonnel = 1140;
  const recentCheckInCount = 1042;
  const recentCheckInRate = '91.4%';
  const activeRequestsCount = 14;
  const ongoingInterventionsCount = interventions.filter(i => i.status !== 'Completed').length;
  const pendingFollowupsCount = interventions.filter(i => i.status === 'Follow-up').length;

  const handleAttentionAction = (item: typeof ATTENTION_ITEMS[0]) => {
    if (item.targetPage === 'interventions') {
      if (item.relatedInterventionId) {
        setSelectedInterventionId(item.relatedInterventionId);
      }
      setCurrentPage('interventions');
    } else if (item.targetPage === 'unit-overview') {
      if (item.relatedSubUnit) {
        setSelectedSubUnitFilter(item.relatedSubUnit);
      }
      setCurrentPage('unit-overview');
    }
  };

  const handleActivityClick = (interventionId?: string) => {
    if (interventionId) {
      setSelectedInterventionId(interventionId);
      setCurrentPage('interventions');
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header Context Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {getGreeting()}
            </h2>
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
              {currentUser?.rank || 'Commandant'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1 flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-slate-700">Unit Welfare Overview</span>
            <span>•</span>
            <span>Current Reporting Period (Q3 FY26)</span>
            <span>•</span>
            <span className="text-slate-500">142 Battalion (Headquarters &amp; 5 Forward Detachments)</span>
          </p>
        </div>

        {/* Quick controls */}
        <div className="flex items-center gap-2">
          <div className="flex bg-slate-50 p-1 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => setTimeRange('week')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                timeRange === 'week'
                  ? 'bg-white shadow-xs border border-slate-200 text-slate-800'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Current Week
            </button>
            <button
              onClick={() => setTimeRange('month')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                timeRange === 'month'
                  ? 'bg-white shadow-xs border border-slate-200 text-slate-800'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              This Month
            </button>
            <button
              onClick={() => setTimeRange('quarter')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                timeRange === 'quarter'
                  ? 'bg-white shadow-xs border border-slate-200 text-slate-800'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Quarterly
            </button>
          </div>
        </div>
      </div>

      {/* Top 4 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Total Personnel */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 text-xs font-bold uppercase tracking-wide">Total Personnel</span>
            <div className="p-1.5 rounded-lg bg-slate-100 text-slate-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-light mt-1 text-slate-900">1,140</div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
            <span>1,085 active duty</span>
            <span>55 leave/course</span>
          </div>
        </div>

        {/* 2. Recent Check-ins */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 text-xs font-bold uppercase tracking-wide">Recent Check-ins</span>
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-light mt-1 text-slate-900 flex items-baseline gap-2">
            <span>{recentCheckInRate}</span>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
              +1.8%
            </span>
          </div>
          <div className="mt-3 flex items-center text-xs text-slate-400">
            <span className="text-emerald-600 mr-1 font-medium">+1.8%</span>
            <span>{recentCheckInCount} of {totalPersonnel} completed this cycle</span>
          </div>
        </div>

        {/* 3. Active Support Requests */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 text-xs font-bold uppercase tracking-wide">Active Requests</span>
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-700">
              <HelpCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-light mt-1 text-slate-900">{activeRequestsCount}</div>
          <div className="mt-3 flex items-center text-xs text-slate-400">
            <span className="text-amber-600 mr-1 font-medium">4 triage</span>
            <span>10 under welfare coordination</span>
          </div>
        </div>

        {/* 4. Ongoing Interventions */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 text-xs font-bold uppercase tracking-wide">Interventions</span>
            <div className="p-1.5 rounded-lg bg-teal-50 text-teal-700">
              <LifeBuoy className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-light mt-1 text-slate-900 flex items-baseline gap-2">
            <span>{ongoingInterventionsCount}</span>
            {pendingFollowupsCount > 0 && (
              <span className="text-xs font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-full border border-teal-100">
                {pendingFollowupsCount} follow-up
              </span>
            )}
          </div>
          <div className="mt-3 flex items-center text-xs text-slate-400">
            <span className="text-teal-600 mr-1 font-medium">Supervised</span>
            <span>Medical &amp; Welfare Staff</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Unit Activity Visualization + Areas Requiring Attention */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Unit Activity Overview Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                  Unit Activity Overview
                </h3>
                <p className="text-xs text-slate-500">
                  Aggregated participation trends &amp; support request volume across reporting weeks
                </p>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex bg-slate-50 p-1 rounded-lg border border-slate-200 text-xs">
                  <button
                    onClick={() => setActivityMetric('participation')}
                    className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                      activityMetric === 'participation'
                        ? 'bg-white shadow-xs border border-slate-200 text-slate-800'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Check-in Rate (%)
                  </button>
                  <button
                    onClick={() => setActivityMetric('requests')}
                    className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                      activityMetric === 'requests'
                        ? 'bg-white shadow-xs border border-slate-200 text-slate-800'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Support Volume (Count)
                  </button>
                </div>
              </div>
            </div>

            {/* Recharts Aggregated Visual */}
            <div className="h-64 mt-4 w-full">
              <ResponsiveContainer width="100%" height="100%">
                {activityMetric === 'participation' ? (
                  <AreaChart data={PARTICIPATION_TRENDS} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="rateGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0D9488" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#0D9488" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis dataKey="week" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#CBD5E1" />
                    <YAxis domain={[80, 100]} tick={{ fontSize: 11, fill: '#64748B' }} stroke="#CBD5E1" unit="%" />
                    <Tooltip
                      formatter={(val: any) => [`${val}% Check-in Rate`, 'Participation']}
                      contentStyle={{
                        backgroundColor: '#0F172A',
                        borderRadius: '8px',
                        color: '#F8FAFC',
                        border: 'none',
                        fontSize: '12px',
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="rate"
                      stroke="#0D9488"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#rateGradient)"
                    />
                  </AreaChart>
                ) : (
                  <BarChart data={PARTICIPATION_TRENDS} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis dataKey="week" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#CBD5E1" />
                    <YAxis tick={{ fontSize: 11, fill: '#64748B' }} stroke="#CBD5E1" />
                    <Tooltip
                      formatter={(val: any) => [`${val} requests`, 'Support Inquiries']}
                      contentStyle={{
                        backgroundColor: '#0F172A',
                        borderRadius: '8px',
                        color: '#F8FAFC',
                        border: 'none',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="requests" fill="#0D9488" radius={[4, 4, 0, 0]} maxBarSize={36} />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Unit-Level Aggregation Only · Zero Surveillance Protocol Active</span>
            </span>
            <button
              onClick={() => setCurrentPage('unit-overview')}
              className="text-teal-600 hover:text-teal-800 font-bold flex items-center gap-1"
            >
              <span>Explore Sub-Units</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right 1 Col: Areas Requiring Attention */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                  Areas Requiring Attention
                </h3>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-100">
                {ATTENTION_ITEMS.length} Items
              </span>
            </div>

            {/* List of Attention Items */}
            <div className="space-y-2 mt-3.5">
              {ATTENTION_ITEMS.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleAttentionAction(item)}
                  className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-200 cursor-pointer"
                >
                  <div
                    className={`w-2 h-2 mt-1.5 rounded-full shrink-0 ${
                      item.priority === 'Urgent'
                        ? 'bg-rose-500'
                        : item.priority === 'Moderate'
                        ? 'bg-amber-500'
                        : 'bg-slate-400'
                    }`}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h4 className="text-xs font-bold text-slate-900 truncate">
                        {item.title}
                      </h4>
                      <PriorityBadge priority={item.priority} size="sm" />
                    </div>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed line-clamp-2">
                      {item.description}
                    </p>
                    <div className="mt-2 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">{item.timestamp}</span>
                      <span className="font-bold text-teal-600 hover:text-teal-800 flex items-center gap-0.5">
                        <span>{item.actionText}</span>
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100">
            <button
              onClick={() => setCurrentPage('interventions')}
              className="w-full py-2 text-xs font-bold text-teal-600 bg-teal-50 border border-teal-100 rounded-lg hover:bg-teal-100 transition-colors text-center"
            >
              Open Full Intervention Management →
            </button>
          </div>
        </div>
      </div>

      {/* Recent Activity Timeline & Sub-Unit Quick Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Recent Operational Activity */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-600" />
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Recent Unit Support Activity
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-medium">Real-time operational log</span>
          </div>

          <div className="divide-y divide-slate-100 mt-2">
            {RECENT_ACTIVITIES.map((activity) => (
              <div
                key={activity.id}
                onClick={() => handleActivityClick(activity.interventionId)}
                className={`py-3 flex items-start justify-between gap-3 ${
                  activity.interventionId ? 'cursor-pointer hover:bg-slate-50 -mx-2 px-2 rounded-lg transition-colors' : ''
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-1.5 h-2 w-2 rounded-full bg-teal-600 shrink-0" />
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-bold text-slate-900">{activity.title}</p>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                        {activity.subUnit}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5 leading-snug">
                      {activity.description}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[11px] text-slate-400 block">{activity.timestamp}</span>
                  {activity.interventionId && (
                    <span className="text-[10px] text-teal-600 font-semibold flex items-center justify-end gap-0.5 mt-0.5">
                      <span>View Case</span>
                      <ChevronRight className="w-3 h-3" />
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right 1 Col: Quick Sub-Unit Roster Glance */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-slate-700" />
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                  Sub-Unit Health Roster
                </h3>
              </div>
              <button
                onClick={() => setCurrentPage('unit-overview')}
                className="text-xs text-teal-600 font-bold hover:underline"
              >
                Details
              </button>
            </div>

            <div className="space-y-2 mt-3">
              {[
                { name: 'HQ Company', rate: 94.5, active: 1, personnel: 220 },
                { name: 'Alpha Company', rate: 92.1, active: 2, personnel: 235 },
                { name: 'Bravo Company', rate: 88.6, active: 2, personnel: 228 },
                { name: 'Charlie Company', rate: 84.3, active: 3, personnel: 242 },
                { name: 'Delta Company', rate: 93.8, active: 1, personnel: 215 },
              ].map((coy) => (
                <div
                  key={coy.name}
                  onClick={() => {
                    setSelectedSubUnitFilter(coy.name);
                    setCurrentPage('unit-overview');
                  }}
                  className="p-3 rounded-lg border border-transparent hover:border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors flex items-center justify-between"
                >
                  <div>
                    <p className="text-xs font-bold text-slate-800">{coy.name}</p>
                    <p className="text-[11px] text-slate-400">{coy.personnel} personnel assigned</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1.5 justify-end">
                      <span className="text-xs font-bold text-slate-900">{coy.rate}%</span>
                      <span className={`h-2 w-2 rounded-full ${coy.rate > 90 ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                    </div>
                    <span className="text-[10px] text-slate-400">{coy.active} active interventions</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100">
            <button
              onClick={() => setPrivacyModalOpen(true)}
              className="w-full text-center text-xs text-slate-500 hover:text-slate-800 flex items-center justify-center gap-1 font-medium"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Review Privacy &amp; Access Boundaries</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Intervention, InterventionStatus, InterventionPriority, InterventionCategory } from '../types';
import { 
  Search, 
  Filter, 
  Plus, 
  ArrowUpDown, 
  Calendar, 
  UserCheck, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ChevronRight, 
  Send, 
  CheckSquare, 
  Building2, 
  ShieldCheck, 
  User, 
  FileText,
  X,
  ExternalLink,
  ChevronDown
} from 'lucide-react';
import { StatusBadge, PriorityBadge } from '../components/common/StatusBadge';
import { NewInterventionModal } from '../components/interventions/NewInterventionModal';
import { ResolveCaseModal } from '../components/interventions/ResolveCaseModal';

export const InterventionsPage: React.FC = () => {
  const { 
    interventions, 
    supportProfessionals, 
    selectedInterventionId, 
    setSelectedInterventionId,
    updateInterventionStatus,
    assignProfessional,
    addInterventionNote,
    markInterventionComplete,
    setFollowUpDate,
    currentUser
  } = useApp();

  // Search and Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [subUnitFilter, setSubUnitFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<'id' | 'createdAt' | 'priority' | 'status' | 'updatedAt'>('updatedAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Modals
  const [newCaseModalOpen, setNewCaseModalOpen] = useState(false);
  const [resolveModalOpen, setResolveModalOpen] = useState(false);

  // Operational action states for active detail workspace
  const [newNoteText, setNewNoteText] = useState('');
  const [followUpInputDate, setFollowUpInputDate] = useState('');
  const [statusSelectValue, setStatusSelectValue] = useState<InterventionStatus | ''>('');
  const [profSelectValue, setProfSelectValue] = useState<string>('');

  // Selected intervention
  const activeIntervention = useMemo(() => {
    if (!selectedInterventionId) {
      return interventions[0] || null;
    }
    return interventions.find((i) => i.id === selectedInterventionId) || interventions[0] || null;
  }, [interventions, selectedInterventionId]);

  // Filtered & sorted interventions
  const filteredInterventions = useMemo(() => {
    return interventions
      .filter((item) => {
        // Search
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesId = item.id.toLowerCase().includes(q);
          const matchesCat = item.category.toLowerCase().includes(q);
          const matchesSummary = item.summary.toLowerCase().includes(q);
          const matchesProf = (item.assignedProfessionalName || '').toLowerCase().includes(q);
          const matchesCoy = item.subUnit.toLowerCase().includes(q);
          if (!matchesId && !matchesCat && !matchesSummary && !matchesProf && !matchesCoy) {
            return false;
          }
        }

        // Status
        if (statusFilter !== 'all' && item.status !== statusFilter) {
          return false;
        }

        // Priority
        if (priorityFilter !== 'all' && item.priority !== priorityFilter) {
          return false;
        }

        // Sub-unit
        if (subUnitFilter !== 'all' && item.subUnit !== subUnitFilter) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        let valA: any = a[sortField];
        let valB: any = b[sortField];

        if (sortField === 'priority') {
          const priorityRank: Record<InterventionPriority, number> = {
            Urgent: 4,
            High: 3,
            Medium: 2,
            Low: 1,
          };
          valA = priorityRank[a.priority];
          valB = priorityRank[b.priority];
        }

        if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
  }, [interventions, searchQuery, statusFilter, priorityFilter, subUnitFilter, sortField, sortOrder]);

  const handleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeIntervention || !newNoteText.trim()) return;
    addInterventionNote(activeIntervention.id, newNoteText, currentUser?.role || 'Commandant');
    setNewNoteText('');
  };

  const handleAssignProfessionalChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const profId = e.target.value;
    setProfSelectValue(profId);
    if (!profId || !activeIntervention) return;
    const prof = supportProfessionals.find((p) => p.id === profId);
    if (prof) {
      assignProfessional(activeIntervention.id, prof.id, `${prof.name} (${prof.role})`);
    }
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatus = e.target.value as InterventionStatus;
    setStatusSelectValue(newStatus);
    if (!newStatus || !activeIntervention) return;

    if (newStatus === 'Completed') {
      setResolveModalOpen(true);
    } else {
      updateInterventionStatus(activeIntervention.id, newStatus);
    }
  };

  const handleScheduleFollowUp = () => {
    if (!activeIntervention || !followUpInputDate) return;
    setFollowUpDate(activeIntervention.id, followUpInputDate);
    setFollowUpInputDate('');
  };

  // Status Lifecycle Progression Definition
  const LIFECYCLE_STEPS: InterventionStatus[] = ['Created', 'Assigned', 'In Progress', 'Follow-up', 'Completed'];

  const getStepStatus = (step: InterventionStatus, current: InterventionStatus) => {
    const currentIndex = LIFECYCLE_STEPS.indexOf(current);
    const stepIndex = LIFECYCLE_STEPS.indexOf(step);

    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'active';
    return 'pending';
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-2 border-b border-slate-200">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Intervention Details &amp; Operational Management
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Coordinate medical, counselling, administrative, and family support cases under authorized command oversight
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="open-new-referral-btn"
            onClick={() => setNewCaseModalOpen(true)}
            className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Initiate Support Referral</span>
          </button>
        </div>
      </div>

      {/* Operational Search & Multi-Filter Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search bar */}
          <div className="lg:col-span-2 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              placeholder="Search by ID, keyword, sub-unit, or assignee..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:border-teal-600 focus:bg-white"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-hidden focus:border-teal-600"
            >
              <option value="all">All Statuses</option>
              <option value="Created">Created (Triage)</option>
              <option value="Assigned">Assigned</option>
              <option value="In Progress">In Progress</option>
              <option value="Follow-up">Follow-up Due</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          {/* Priority Filter */}
          <div>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-hidden focus:border-teal-600"
            >
              <option value="all">All Priorities</option>
              <option value="Urgent">Urgent Priority</option>
              <option value="High">High Priority</option>
              <option value="Medium">Medium Priority</option>
              <option value="Low">Low Priority</option>
            </select>
          </div>

          {/* Sub-unit Filter */}
          <div>
            <select
              value={subUnitFilter}
              onChange={(e) => setSubUnitFilter(e.target.value)}
              className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-hidden focus:border-teal-600"
            >
              <option value="all">All Companies</option>
              <option value="HQ Company">HQ Company</option>
              <option value="Alpha Company">Alpha Company</option>
              <option value="Bravo Company">Bravo Company</option>
              <option value="Charlie Company">Charlie Company</option>
              <option value="Delta Company">Delta Company</option>
            </select>
          </div>
        </div>

        {/* Filter count indicator */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Showing <strong>{filteredInterventions.length}</strong> of <strong>{interventions.length}</strong> total unit cases</span>
          {(statusFilter !== 'all' || priorityFilter !== 'all' || subUnitFilter !== 'all' || searchQuery) && (
            <button
              onClick={() => {
                setStatusFilter('all');
                setPriorityFilter('all');
                setSubUnitFilter('all');
                setSearchQuery('');
              }}
              className="text-teal-600 hover:text-teal-800 font-bold underline"
            >
              Clear all filters
            </button>
          )}
        </div>
      </div>

      {/* Core Split Workspace: Table & Detail Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Interventions Table (7 cols on lg) */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-white">
            <h3 className="text-sm font-bold text-slate-900">
              Active &amp; Historical Interventions
            </h3>
            <span className="text-xs text-slate-400">Click any row to inspect</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                  <th
                    className="py-3 px-3.5 cursor-pointer hover:text-slate-800"
                    onClick={() => handleSort('id')}
                  >
                    <div className="flex items-center gap-1">
                      <span>Case ID</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="py-3 px-3">Category</th>
                  <th
                    className="py-3 px-3 cursor-pointer hover:text-slate-800"
                    onClick={() => handleSort('status')}
                  >
                    <div className="flex items-center gap-1">
                      <span>Status</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    className="py-3 px-3 cursor-pointer hover:text-slate-800"
                    onClick={() => handleSort('priority')}
                  >
                    <div className="flex items-center gap-1">
                      <span>Priority</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="py-3 px-3">Assigned Officer</th>
                  <th
                    className="py-3 px-3.5 cursor-pointer hover:text-slate-800 text-right"
                    onClick={() => handleSort('updatedAt')}
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Updated</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInterventions.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-10 text-center text-slate-400">
                      <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                      <p className="text-sm font-semibold text-slate-600">No matching interventions</p>
                      <p className="text-xs text-slate-400 mt-1">Try relaxing your search terms or filter constraints.</p>
                    </td>
                  </tr>
                ) : (
                  filteredInterventions.map((item) => {
                    const isSelected = activeIntervention?.id === item.id;
                    return (
                      <tr
                        key={item.id}
                        id={`row-${item.id}`}
                        onClick={() => setSelectedInterventionId(item.id)}
                        className={`cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-teal-50/70 font-medium'
                            : 'hover:bg-slate-50'
                        }`}
                      >
                        <td className="py-3 px-3.5 whitespace-nowrap">
                          <span className="font-mono font-bold text-teal-700">{item.id}</span>
                          <span className="block text-[10px] text-slate-400">{item.subUnit}</span>
                        </td>
                        <td className="py-3 px-3 font-medium text-slate-800">
                          {item.category}
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <StatusBadge status={item.status} size="sm" />
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <PriorityBadge priority={item.priority} size="sm" />
                        </td>
                        <td className="py-3 px-3 text-slate-600 max-w-[140px] truncate">
                          {item.assignedProfessionalName ? (
                            <span className="truncate block" title={item.assignedProfessionalName}>
                              {item.assignedProfessionalName.split('(')[0]}
                            </span>
                          ) : (
                            <span className="text-amber-600 italic">Unassigned</span>
                          )}
                        </td>
                        <td className="py-3 px-3.5 text-right whitespace-nowrap text-slate-400 font-mono text-[11px]">
                          {new Date(item.updatedAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Selected Intervention Detail Workspace (5 cols on lg) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-5">
          {activeIntervention ? (
            <>
              {/* Detail Header */}
              <div className="pb-3 border-b border-slate-100">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-base font-bold text-teal-700">
                        {activeIntervention.id}
                      </span>
                      <PriorityBadge priority={activeIntervention.priority} size="sm" />
                    </div>
                    <h3 className="text-sm font-bold text-slate-900 mt-1">
                      {activeIntervention.category}
                    </h3>
                  </div>
                  <StatusBadge status={activeIntervention.status} />
                </div>

                <div className="mt-2 flex items-center gap-2 text-xs text-slate-500 flex-wrap">
                  <span className="flex items-center gap-1 font-semibold text-slate-700">
                    <Building2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>{activeIntervention.subUnit}</span>
                  </span>
                  <span>•</span>
                  <span>Logged: {new Date(activeIntervention.createdAt).toLocaleDateString()}</span>
                </div>
              </div>

              {/* Status Progression Flow */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Support Lifecycle Stage
                </label>
                <div className="flex items-center justify-between relative">
                  {/* Track line behind */}
                  <div className="absolute top-1/2 left-3 right-3 -translate-y-1/2 h-0.5 bg-slate-200 -z-0" />

                  {LIFECYCLE_STEPS.map((step, idx) => {
                    const stepState = getStepStatus(step, activeIntervention.status);
                    let iconBg = 'bg-slate-200 text-slate-500';
                    let labelColor = 'text-slate-400';

                    if (stepState === 'completed') {
                      iconBg = 'bg-emerald-600 text-white';
                      labelColor = 'text-emerald-700 font-semibold';
                    } else if (stepState === 'active') {
                      iconBg = 'bg-teal-600 text-white ring-4 ring-teal-100';
                      labelColor = 'text-teal-700 font-bold';
                    }

                    return (
                      <div key={step} className="flex flex-col items-center relative z-10">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${iconBg}`}
                        >
                          {stepState === 'completed' ? '✓' : idx + 1}
                        </div>
                        <span className={`text-[10px] mt-1 whitespace-nowrap ${labelColor}`}>
                          {step}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Case Summary */}
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed">
                <p className="font-semibold text-slate-900 mb-1">Scope of Support:</p>
                <p>{activeIntervention.summary}</p>
                {activeIntervention.resolutionSummary && (
                  <div className="mt-2 pt-2 border-t border-slate-200 text-emerald-800">
                    <strong>Resolution Note:</strong> {activeIntervention.resolutionSummary}
                  </div>
                )}
              </div>

              {/* Commander Action Controls */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">
                    Commander Action Controls
                  </span>
                  {activeIntervention.nextFollowUpDate && (
                    <span className="text-[11px] font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-full border border-teal-100">
                      Follow-up: {activeIntervention.nextFollowUpDate}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Status update select */}
                  <div>
                    <label htmlFor="update-status-select" className="text-[10px] font-semibold text-slate-600 block mb-1">
                      Update Stage
                    </label>
                    <select
                      id="update-status-select"
                      value={activeIntervention.status}
                      onChange={handleStatusChange}
                      className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:outline-hidden focus:border-teal-600"
                    >
                      <option value="Created">Created</option>
                      <option value="Assigned">Assigned</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Follow-up">Follow-up</option>
                      <option value="Completed">Mark as Completed</option>
                    </select>
                  </div>

                  {/* Assign support professional */}
                  <div>
                    <label htmlFor="assign-prof-select" className="text-[10px] font-semibold text-slate-600 block mb-1">
                      Assign Professional
                    </label>
                    <select
                      id="assign-prof-select"
                      value={activeIntervention.assignedProfessionalId || ''}
                      onChange={handleAssignProfessionalChange}
                      className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:outline-hidden focus:border-teal-600"
                    >
                      <option value="">Unassigned</option>
                      {supportProfessionals.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({p.role})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Follow-up date picker */}
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="date"
                    value={followUpInputDate}
                    onChange={(e) => setFollowUpInputDate(e.target.value)}
                    className="text-xs bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:outline-hidden focus:border-teal-600"
                  />
                  <button
                    onClick={handleScheduleFollowUp}
                    disabled={!followUpInputDate}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors disabled:opacity-40"
                  >
                    Set Follow-up Date
                  </button>
                </div>
              </div>

              {/* Chronological Notes Feed */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Chronological Operational Notes ({activeIntervention.notes.length})
                  </h4>
                  <span className="text-[10px] text-slate-400">Strictly confidential</span>
                </div>

                {/* Note input */}
                <form onSubmit={handleAddNote} className="space-y-2">
                  <div className="relative">
                    <textarea
                      rows={2}
                      placeholder="Add an operational or welfare update (e.g. Hospital coordinator contacted; travel requisition signed)..."
                      value={newNoteText}
                      onChange={(e) => setNewNoteText(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:border-teal-600 focus:bg-white"
                    />
                  </div>
                  <div className="flex justify-end">
                    <button
                      id="append-note-btn"
                      type="submit"
                      disabled={!newNoteText.trim()}
                      className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 disabled:opacity-40"
                    >
                      <Send className="w-3 h-3" />
                      <span>Append Update</span>
                    </button>
                  </div>
                </form>

                {/* Notes List */}
                <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                  {activeIntervention.notes.map((note) => (
                    <div
                      key={note.id}
                      className="p-3 rounded-lg border border-slate-200 bg-white text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold text-slate-900 flex items-center gap-1">
                          <User className="w-3 h-3 text-slate-400" />
                          <span>{note.authorName}</span>
                          <span className="text-slate-400 font-normal">({note.authorRole})</span>
                        </span>
                        <span className="text-slate-400 font-mono text-[10px]">
                          {new Date(note.timestamp).toLocaleDateString()} {new Date(note.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-slate-700 leading-relaxed pt-0.5">{note.content}</p>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-12 text-slate-400">
              <FileText className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              <p className="text-sm font-semibold text-slate-600">Select an intervention</p>
              <p className="text-xs text-slate-400">Choose a case from the table to inspect details</p>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <NewInterventionModal
        isOpen={newCaseModalOpen}
        onClose={() => setNewCaseModalOpen(false)}
        onSuccessSelectId={(id) => setSelectedInterventionId(id)}
      />

      {activeIntervention && (
        <ResolveCaseModal
          isOpen={resolveModalOpen}
          onClose={() => setResolveModalOpen(false)}
          caseId={activeIntervention.id}
          onConfirm={(resolution) => {
            markInterventionComplete(activeIntervention.id, resolution);
          }}
        />
      )}
    </div>
  );
};

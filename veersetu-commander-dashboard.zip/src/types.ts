export type UserRole = 'Commandant' | 'Second-in-Command' | 'Welfare Officer' | 'Medical Officer';

export interface UserProfile {
  id: string;
  name: string;
  serviceId: string;
  email: string;
  phone: string;
  rank: string;
  unit: string;
  avatarUrl?: string;
  twoFactorEnabled: boolean;
  role: UserRole;
}

export type InterventionStatus = 'Created' | 'Assigned' | 'In Progress' | 'Follow-up' | 'Completed';

export type InterventionPriority = 'Low' | 'Medium' | 'High' | 'Urgent';

export type InterventionCategory = 
  | 'Counselling Support'
  | 'Personal Assistance'
  | 'Professional Support'
  | 'Medical Liaison'
  | 'Family Welfare'
  | 'Administrative Support'
  | 'Post-Deployment Reintegration';

export interface InterventionNote {
  id: string;
  timestamp: string;
  authorName: string;
  authorRole: string;
  content: string;
  isConfidential?: boolean;
}

export interface SupportProfessional {
  id: string;
  name: string;
  role: string;
  designation: string;
  contact: string;
  activeCasesCount: number;
}

export interface Intervention {
  id: string;
  category: InterventionCategory;
  createdAt: string;
  updatedAt: string;
  status: InterventionStatus;
  priority: InterventionPriority;
  assignedProfessionalId?: string;
  assignedProfessionalName?: string;
  subUnit: string; // e.g. 'Alpha Company', 'Bravo Company', 'HQ Company'
  summary: string;
  nextFollowUpDate?: string;
  notes: InterventionNote[];
  resolutionSummary?: string;
}

export interface AttentionItem {
  id: string;
  title: string;
  description: string;
  priority: 'Urgent' | 'Moderate' | 'Operational';
  category: string;
  timestamp: string;
  relatedInterventionId?: string;
  relatedSubUnit?: string;
  actionText: string;
  targetPage: 'dashboard' | 'unit-overview' | 'interventions';
}

export interface RecentActivityItem {
  id: string;
  timestamp: string;
  title: string;
  description: string;
  type: 'request_received' | 'assigned' | 'status_updated' | 'followup_logged' | 'completed';
  interventionId?: string;
  subUnit: string;
}

export interface SubUnitData {
  id: string;
  name: string;
  personnelCount: number;
  checkInRate: number; // percentage
  activeRequests: number;
  ongoingInterventions: number;
  location: string;
  commanderInCharge: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'urgent' | 'update' | 'reminder';
  linkTarget?: string;
}

export interface DashboardFilterState {
  timeframe: '7d' | '30d' | '90d' | 'all';
  subUnit: string;
  status: string;
  priority: string;
  category: string;
  searchQuery: string;
}

export interface NotificationSettings {
  newSupportRequests: boolean;
  interventionUpdates: boolean;
  followUpReminders: boolean;
  weeklyWelfareDigest: boolean;
  smsUrgentAlerts: boolean;
}

export type ThemeMode = 'light' | 'dark' | 'system';

export interface DashboardPreferences {
  theme?: ThemeMode;
  defaultReportingPeriod: '7d' | '30d' | '90d';
  defaultSubUnit: string;
  compactTableMode: boolean;
  confidentialMasking: boolean;
}

import React from 'react';
import { Sidebar } from './Sidebar';
import { TopNavbar } from './TopNavbar';
import { BottomNav } from './BottomNav';
import { ToastContainer } from './ToastContainer';
import { useApp } from '../../context/AppContext';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { sidebarCollapsed } = useApp();

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1B263B] flex flex-col">
      {/* Off-canvas on Mobile / Collapsible on Desktop Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${
          sidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64'
        }`}
      >
        {/* Top Navbar */}
        <TopNavbar />

        {/* Dynamic Page Workspace with safe bottom space for mobile BottomNav */}
        <main className="flex-1 px-4 py-5 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto pb-24 lg:pb-8">
          {children}
        </main>

        {/* Natural Tones System Footer (lifted above bottom nav on mobile) */}
        <footer className="h-11 bg-[#E0E1DD]/60 border-t border-[#E0E1DD] flex items-center justify-between px-4 sm:px-8 text-[10px] text-[#778DA9] font-medium mb-16 lg:mb-0">
          <p className="truncate mr-2">© 2026 VeerSetu • CAPF Personnel Welfare</p>
          <div className="hidden sm:flex gap-4 uppercase tracking-wider shrink-0">
            <span>Confidential Care Protocol</span>
            <span>MHA Directive 2026</span>
            <span className="text-[#1B263B] font-bold">V 2.1.0</span>
          </div>
        </footer>
      </div>

      {/* Persistent Mobile Bottom Navigation Bar (Mobile / Tablet only) */}
      <BottomNav />

      {/* Global Notification Toast Container */}
      <ToastContainer />
    </div>
  );
};


import React from 'react';
import {
  LayoutDashboard,
  FolderHeart,
  CalendarDays,
  ClockAlert,
  Menu,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const BottomNav: React.FC = () => {
  const {
    activeRoute,
    navigateTo,
    cases,
    sessions,
    followUps,
    mobileMenuOpen,
    setMobileMenuOpen,
  } = useApp();

  const todayStr = '2026-09-04';
  const todaySessionsCount = sessions.filter((s) => s.date === todayStr && s.status !== 'Completed').length;
  const followUpsDueCount = followUps.filter((f) => f.status === 'Pending' && f.followUpDate <= todayStr).length;
  const priorityCasesCount = cases.filter((c) => c.priority === 'Priority' && c.currentStatus !== 'Completed').length;

  const isCurrentActive = (itemRoute: string) => {
    if (itemRoute === '/cases') {
      return activeRoute === '/cases' || activeRoute.startsWith('/cases/');
    }
    return activeRoute === itemRoute;
  };

  return (
    <nav
      aria-label="Mobile Navigation Bar"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E0E1DD] h-16 px-2 flex items-center justify-around lg:hidden shadow-[0_-4px_12px_rgba(0,0,0,0.05)] safe-area-pb"
    >
      {/* Dashboard */}
      <button
        type="button"
        onClick={() => {
          setMobileMenuOpen(false);
          navigateTo('/dashboard');
        }}
        className={`flex flex-col items-center justify-center flex-1 py-1 px-1 transition-colors min-w-0 cursor-pointer ${
          isCurrentActive('/dashboard') && !mobileMenuOpen
            ? 'text-[#588157]'
            : 'text-[#778DA9] hover:text-[#1B263B]'
        }`}
      >
        <div className="relative">
          <LayoutDashboard className="w-5 h-5" />
          {isCurrentActive('/dashboard') && !mobileMenuOpen && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#588157]" />
          )}
        </div>
        <span className="text-[10px] font-semibold mt-1 truncate max-w-full">
          Dashboard
        </span>
      </button>

      {/* Cases */}
      <button
        type="button"
        onClick={() => {
          setMobileMenuOpen(false);
          navigateTo('/cases');
        }}
        className={`flex flex-col items-center justify-center flex-1 py-1 px-1 transition-colors min-w-0 cursor-pointer relative ${
          isCurrentActive('/cases') && !mobileMenuOpen
            ? 'text-[#588157]'
            : 'text-[#778DA9] hover:text-[#1B263B]'
        }`}
      >
        <div className="relative">
          <FolderHeart className="w-5 h-5" />
          {priorityCasesCount > 0 && (
            <span className="absolute -top-1 -right-1.5 min-w-3.5 h-3.5 px-0.5 text-[9px] font-bold rounded-full bg-[#E63946] text-white flex items-center justify-center ring-2 ring-white">
              {priorityCasesCount}
            </span>
          )}
          {isCurrentActive('/cases') && !mobileMenuOpen && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#588157]" />
          )}
        </div>
        <span className="text-[10px] font-semibold mt-1 truncate max-w-full">
          Cases
        </span>
      </button>

      {/* Sessions */}
      <button
        type="button"
        onClick={() => {
          setMobileMenuOpen(false);
          navigateTo('/sessions');
        }}
        className={`flex flex-col items-center justify-center flex-1 py-1 px-1 transition-colors min-w-0 cursor-pointer relative ${
          isCurrentActive('/sessions') && !mobileMenuOpen
            ? 'text-[#588157]'
            : 'text-[#778DA9] hover:text-[#1B263B]'
        }`}
      >
        <div className="relative">
          <CalendarDays className="w-5 h-5" />
          {todaySessionsCount > 0 && (
            <span className="absolute -top-1 -right-1.5 min-w-3.5 h-3.5 px-0.5 text-[9px] font-bold rounded-full bg-[#588157] text-white flex items-center justify-center ring-2 ring-white">
              {todaySessionsCount}
            </span>
          )}
          {isCurrentActive('/sessions') && !mobileMenuOpen && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#588157]" />
          )}
        </div>
        <span className="text-[10px] font-semibold mt-1 truncate max-w-full">
          Sessions
        </span>
      </button>

      {/* Follow-ups */}
      <button
        type="button"
        onClick={() => {
          setMobileMenuOpen(false);
          navigateTo('/follow-ups');
        }}
        className={`flex flex-col items-center justify-center flex-1 py-1 px-1 transition-colors min-w-0 cursor-pointer relative ${
          isCurrentActive('/follow-ups') && !mobileMenuOpen
            ? 'text-[#588157]'
            : 'text-[#778DA9] hover:text-[#1B263B]'
        }`}
      >
        <div className="relative">
          <ClockAlert className="w-5 h-5" />
          {followUpsDueCount > 0 && (
            <span className="absolute -top-1 -right-1.5 min-w-3.5 h-3.5 px-0.5 text-[9px] font-bold rounded-full bg-[#B45309] text-white flex items-center justify-center ring-2 ring-white">
              {followUpsDueCount}
            </span>
          )}
          {isCurrentActive('/follow-ups') && !mobileMenuOpen && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#588157]" />
          )}
        </div>
        <span className="text-[10px] font-semibold mt-1 truncate max-w-full">
          Follow-ups
        </span>
      </button>

      {/* More / Menu Drawer Toggle */}
      <button
        type="button"
        onClick={() => setMobileMenuOpen((prev) => !prev)}
        className={`flex flex-col items-center justify-center flex-1 py-1 px-1 transition-colors min-w-0 cursor-pointer ${
          mobileMenuOpen
            ? 'text-[#588157]'
            : 'text-[#778DA9] hover:text-[#1B263B]'
        }`}
      >
        <div className="relative">
          {mobileMenuOpen ? (
            <X className="w-5 h-5 text-[#588157]" />
          ) : (
            <Menu className="w-5 h-5" />
          )}
        </div>
        <span className="text-[10px] font-semibold mt-1 truncate max-w-full">
          {mobileMenuOpen ? 'Close' : 'More'}
        </span>
      </button>
    </nav>
  );
};

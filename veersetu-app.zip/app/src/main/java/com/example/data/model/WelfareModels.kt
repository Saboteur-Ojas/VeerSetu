package com.example.data.model

enum class RetentionZone(val displayName: String, val shortName: String, val description: String) {
    HIGH("High Retention Zone", "High Zone", "High operational demands and remote duty rotation"),
    MID("Mid Retention Zone", "Mid Zone", "Standard operational rotation and active deployment"),
    LOW("Low Retention Zone", "Low Zone", "Base establishment and peace station rotation")
}

data class PersonnelProfile(
    val serviceId: String,
    val email: String,
    val phoneNumber: String,
    val retentionZone: RetentionZone = RetentionZone.HIGH,
    val pseudonym: String = "CASE-VS-7A91",
    val registrationDate: String = "Sep 2026"
)

data class CheckInEntry(
    val id: String,
    val dateLabel: String,
    val timestamp: Long,
    val feelingLevel: Int, // 1 to 5
    val stressLevel: Int, // 1 to 5
    val fatigueLevel: Int, // 1 to 5
    val recoveryLevel: Int, // 1 to 5
    val note: String? = null,
    val feelingText: String = "Good",
    val stressText: String = "Moderate",
    val fatigueText: String = "Mild",
    val recoveryText: String = "Good"
)

enum class AppointmentStatus(val label: String) {
    REQUESTED("Requested"),
    SCHEDULED("Scheduled"),
    COMPLETED("Completed"),
    FOLLOW_UP("Follow-up")
}

data class Appointment(
    val id: String,
    val professionalRole: String,
    val dateText: String,
    val timeSlot: String,
    val mode: String,
    val status: AppointmentStatus,
    val locationOrChannel: String
)

data class AuditAccessLog(
    val id: String,
    val timestampText: String,
    val role: String,
    val action: String,
    val scope: String
)

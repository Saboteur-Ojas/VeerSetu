package com.example.data.repository

import com.example.data.model.Appointment
import com.example.data.model.AppointmentStatus
import com.example.data.model.AuditAccessLog
import com.example.data.model.CheckInEntry
import com.example.data.model.PersonnelProfile
import com.example.data.model.RetentionZone
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class WelfareRepository {

    // Authentication & Profile
    private val _currentUser = MutableStateFlow<PersonnelProfile?>(
        PersonnelProfile(
            serviceId = "DEF-9842-OP",
            email = "officer.sharma@defense.gov.in",
            phoneNumber = "+91 98450 12345",
            pseudonym = "CASE-VS-7A91",
            registrationDate = "Sep 2026"
        )
    )
    val currentUser: StateFlow<PersonnelProfile?> = _currentUser.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(true)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    // Daily Check-in state
    private val _hasCheckedInToday = MutableStateFlow(false)
    val hasCheckedInToday: StateFlow<Boolean> = _hasCheckedInToday.asStateFlow()

    private val _todayCheckIn = MutableStateFlow<CheckInEntry?>(null)
    val todayCheckIn: StateFlow<CheckInEntry?> = _todayCheckIn.asStateFlow()

    private val _checkInHistory = MutableStateFlow<List<CheckInEntry>>(emptyList())
    val checkInHistory: StateFlow<List<CheckInEntry>> = _checkInHistory.asStateFlow()

    private val _appointments = MutableStateFlow<List<Appointment>>(emptyList())
    val appointments: StateFlow<List<Appointment>> = _appointments.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditAccessLog>>(emptyList())
    val auditLogs: StateFlow<List<AuditAccessLog>> = _auditLogs.asStateFlow()

    // Privacy Controls
    private val _sharePseudonymousWithCounsellor = MutableStateFlow(true)
    val sharePseudonymousWithCounsellor: StateFlow<Boolean> = _sharePseudonymousWithCounsellor.asStateFlow()

    private val _contributeAggregateUnitMetrics = MutableStateFlow(true)
    val contributeAggregateUnitMetrics: StateFlow<Boolean> = _contributeAggregateUnitMetrics.asStateFlow()

    private val _operationalContextSync = MutableStateFlow(true)
    val operationalContextSync: StateFlow<Boolean> = _operationalContextSync.asStateFlow()

    // Theme Mode (Default: Light Mode as requested by user)
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    init {
        initializeSampleData()
    }

    private fun initializeSampleData() {
        _appointments.value = listOf(
            Appointment(
                id = "APT-101",
                professionalRole = "Senior Psychological Support Officer",
                dateText = "Monday, Sep 08",
                timeSlot = "10:30 AM",
                mode = "Confidential In-Person",
                status = AppointmentStatus.SCHEDULED,
                locationOrChannel = "Sector Welfare Centre, Suite 3B"
            ),
            Appointment(
                id = "APT-098",
                professionalRole = "Duty Peer Support Officer",
                dateText = "Aug 22, 2026",
                timeSlot = "02:00 PM",
                mode = "Encrypted Voice Channel",
                status = AppointmentStatus.COMPLETED,
                locationOrChannel = "Secure Terminal VS-Voice"
            )
        )

        _auditLogs.value = listOf(
            AuditAccessLog(
                id = "LOG-409",
                timestampText = "Sep 03, 08:42",
                role = "Duty Counsellor",
                action = "Pseudonymous Welfare Review",
                scope = "Case CASE-VS-7A91 (Session coordination only)"
            ),
            AuditAccessLog(
                id = "LOG-392",
                timestampText = "Sep 01, 14:15",
                role = "Unit Commander Analytics",
                action = "Aggregate Metric Computation",
                scope = "Brigade 14 Welfare Aggregation (K-anonymity >= 25)"
            ),
            AuditAccessLog(
                id = "LOG-350",
                timestampText = "Aug 25, 09:30",
                role = "System Cryptographic Rotator",
                action = "Key Rotation Verification",
                scope = "Local Secure Keystore"
            )
        )
    }

    fun login(
        serviceId: String,
        email: String,
        retentionZone: RetentionZone = RetentionZone.HIGH
    ): Boolean {
        if (serviceId.isBlank() || email.isBlank()) return false
        val existing = _currentUser.value
        _currentUser.value = existing?.copy(
            serviceId = serviceId.trim(),
            email = email.trim(),
            retentionZone = retentionZone
        ) ?: PersonnelProfile(
            serviceId = serviceId.trim(),
            email = email.trim(),
            phoneNumber = "+91 98450 12345",
            retentionZone = retentionZone
        )
        _isLoggedIn.value = true
        return true
    }

    fun register(
        serviceId: String,
        email: String,
        phoneNumber: String,
        retentionZone: RetentionZone = RetentionZone.HIGH
    ): Boolean {
        if (serviceId.isBlank() || email.isBlank() || phoneNumber.isBlank()) {
            return false
        }
        val pseudonym = "CASE-VS-" + serviceId.takeLast(4).uppercase().ifEmpty { "7A91" }
        _currentUser.value = PersonnelProfile(
            serviceId = serviceId.trim(),
            email = email.trim(),
            phoneNumber = phoneNumber.trim(),
            retentionZone = retentionZone,
            pseudonym = pseudonym,
            registrationDate = SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(Date())
        )
        _isLoggedIn.value = true
        return true
    }

    fun logout() {
        _isLoggedIn.value = false
    }

    fun submitCheckIn(
        feeling: Int,
        stress: Int,
        fatigue: Int,
        recovery: Int,
        note: String?
    ) {
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        val dateLabel = dateFormat.format(Date())

        val feelText = when (feeling) {
            1 -> "Very Low"; 2 -> "Low"; 3 -> "Neutral"; 4 -> "Good"; else -> "Very Good"
        }
        val stressText = when (stress) {
            1 -> "Very Low"; 2 -> "Low"; 3 -> "Moderate"; 4 -> "High"; else -> "Very High"
        }
        val fatigueText = when (fatigue) {
            1 -> "No Fatigue"; 2 -> "Mild"; 3 -> "Moderate"; 4 -> "High"; else -> "Severe"
        }
        val recoveryText = when (recovery) {
            1 -> "Poor"; 2 -> "Below Avg"; 3 -> "Average"; 4 -> "Good"; else -> "Excellent"
        }

        val entry = CheckInEntry(
            id = UUID.randomUUID().toString(),
            dateLabel = "Today ($dateLabel)",
            timestamp = System.currentTimeMillis(),
            feelingLevel = feeling,
            stressLevel = stress,
            fatigueLevel = fatigue,
            recoveryLevel = recovery,
            note = note?.takeIf { it.isNotBlank() },
            feelingText = feelText,
            stressText = stressText,
            fatigueText = fatigueText,
            recoveryText = recoveryText
        )

        _todayCheckIn.value = entry
        _hasCheckedInToday.value = true
        _checkInHistory.value = listOf(entry) + _checkInHistory.value
    }

    fun bookAppointment(
        role: String,
        dateText: String,
        timeSlot: String,
        mode: String,
        notes: String
    ): Appointment {
        val newApt = Appointment(
            id = "APT-" + (100..999).random(),
            professionalRole = role,
            dateText = dateText,
            timeSlot = timeSlot,
            mode = mode,
            status = AppointmentStatus.REQUESTED,
            locationOrChannel = if (mode.contains("Person", ignoreCase = true)) "Sector Support Suite" else "Encrypted Terminal"
        )
        _appointments.value = listOf(newApt) + _appointments.value
        return newApt
    }

    fun togglePseudonymousSharing(enabled: Boolean) {
        _sharePseudonymousWithCounsellor.value = enabled
    }

    fun toggleAggregateSharing(enabled: Boolean) {
        _contributeAggregateUnitMetrics.value = enabled
    }

    fun toggleOperationalContextSync(enabled: Boolean) {
        _operationalContextSync.value = enabled
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
    }
}

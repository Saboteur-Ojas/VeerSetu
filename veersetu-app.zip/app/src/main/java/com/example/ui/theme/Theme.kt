package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Indigo500,
    onPrimary = Color.White,
    primaryContainer = Navy800,
    onPrimaryContainer = Indigo100,
    secondary = Teal500,
    onSecondary = Color.White,
    secondaryContainer = Navy800,
    onSecondaryContainer = Teal100,
    tertiary = Sky400,
    onTertiary = Navy950,
    background = Navy950,
    onBackground = Color(0xFFF1F5F9),
    surface = Navy900,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Navy800,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Navy700,
    outlineVariant = Color(0xFF1E293B)
)

private val LightColorScheme = lightColorScheme(
    primary = DefensePrimaryLight,
    onPrimary = Color.White,
    primaryContainer = DefensePrimarySoft,
    onPrimaryContainer = DefensePrimary,
    secondary = WellnessSage,
    onSecondary = Color.White,
    secondaryContainer = WellnessSageSoft,
    onSecondaryContainer = WellnessSage,
    tertiary = Sky600,
    onTertiary = Color.White,
    background = CanvasBgLight,
    onBackground = TextMainLight,
    surface = CardSurfaceLight,
    onSurface = TextMainLight,
    surfaceVariant = CardSurfaceElevatedLight,
    onSurfaceVariant = TextMutedLight,
    outline = BorderSubtleLight,
    outlineVariant = Color(0xFFE2E8F0)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false, // Enforce bespoke VeerSetu defense palette
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

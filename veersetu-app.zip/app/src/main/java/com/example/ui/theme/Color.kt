package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// VeerSetu Palette - Refined Executive Defense Aesthetic
// Clean, luminous, warm-slate light mode and deep dignified obsidian dark mode

// Primary Defense Sapphire / Navy Accents
val DefensePrimary = Color(0xFF1E3A8A)       // Deep Royal Navy - Trustworthy, Authoritative
val DefensePrimaryLight = Color(0xFF2563EB)  // Vibrant Sapphire Accent
val DefensePrimarySoft = Color(0xFFEFF6FF)   // Soft Tint for Selected Items
val DefensePrimaryBorder = Color(0xFFBFDBFE) // Crisp Accent Border

// Secondary Forest/Sage Harmony (Grounding, Wellness)
val WellnessSage = Color(0xFF0D9488)         // Calming Deep Teal
val WellnessSageLight = Color(0xFF14B8A6)    // Fresh Mint
val WellnessSageSoft = Color(0xFFF0FDFA)     // Light Mint Background
val WellnessSageBorder = Color(0xFF99F6E4)   // Mint Border

// Backgrounds & Surface Canvas for LIGHT MODE (Ultra-clean, crisp, elegant contrast)
val CanvasBgLight = Color(0xFFF1F5F9)        // Soft Slate-50 Canvas (avoiding sterile blinding pure white)
val CardSurfaceLight = Color(0xFFFFFFFF)     // Pure White Cards for crisp elevation & depth
val CardSurfaceElevatedLight = Color(0xFFF8FAFC) // Slate-50 for sub-cards & segmented chips
val BorderSubtleLight = Color(0xFFE2E8F0)    // Soft crisp border
val BorderMutedLight = Color(0xFFCBD5E1)     // Defined outline

// Typography Colors for LIGHT MODE
val TextMainLight = Color(0xFF0F172A)        // Slate 900 - high contrast, highly legible
val TextMutedLight = Color(0xFF475569)       // Slate 600 - comfortable readability
val TextSubtleLight = Color(0xFF64748B)      // Slate 500 - assistive text

// Backgrounds & Surface Canvas for DARK MODE
val Navy950 = Color(0xFF090D16)              // Midnight Canvas
val Navy900 = Color(0xFF0F172A)              // Slate Navy
val Navy800 = Color(0xFF1E293B)              // Elevated Dark Card
val Navy700 = Color(0xFF334155)              // Dark Border
val Navy600 = Color(0xFF475569)

val Indigo600 = Color(0xFF2563EB)
val Indigo500 = Color(0xFF3B82F6)
val Indigo100 = Color(0xFFDBEAFE)
val Indigo50 = Color(0xFFEFF6FF)

val Teal600 = Color(0xFF0D9488)
val Teal500 = Color(0xFF14B8A6)
val Teal100 = Color(0xFFCCFBF1)
val Teal50 = Color(0xFFF0FDFA)

val Sky600 = Color(0xFF0284C7)
val Sky400 = Color(0xFF38BDF8)
val Sky50 = Color(0xFFF0F9FF)

val SurfaceLight = CanvasBgLight
val SurfaceCardLight = CardSurfaceLight
val SurfaceCardLightElevated = CardSurfaceElevatedLight
val TextPrimaryLight = TextMainLight
val TextSecondaryLight = TextMutedLight
val TextTertiaryLight = TextSubtleLight
val BorderLight = BorderSubtleLight

// Welfare Status Colors (Dignified, Non-Alarming)
val StatusStable = Color(0xFF059669)         // Emerald 600
val StatusStableBg = Color(0xFFECFDF5)
val StatusStableBorder = Color(0xFFA7F3D0)
val StatusStableText = Color(0xFF065F46)

val StatusConcern = Color(0xFFD97706)        // Amber 600
val StatusConcernBg = Color(0xFFFFFBEB)
val StatusConcernBorder = Color(0xFFFDE68A)
val StatusConcernText = Color(0xFF92400E)

val StatusDeterioration = Color(0xFFEA580C)  // Orange 600
val StatusDeteriorationBg = Color(0xFFFFF7ED)
val StatusDeteriorationBorder = Color(0xFFFED7AA)
val StatusDeteriorationText = Color(0xFF9A3412)

val StatusCriticalRed = Color(0xFFDC2626)
val StatusCriticalBg = Color(0xFFFEF2F2)


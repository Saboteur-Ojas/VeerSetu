package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.SentimentDissatisfied
import androidx.compose.material.icons.filled.SentimentNeutral
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material.icons.filled.SentimentVeryDissatisfied
import androidx.compose.material.icons.filled.SentimentVerySatisfied
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.PrivacyAssuranceChip
import com.example.ui.theme.BorderLight
import com.example.ui.theme.Indigo100
import com.example.ui.theme.Indigo50
import com.example.ui.theme.Indigo500
import com.example.ui.theme.Indigo600
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.StatusStable
import com.example.ui.viewmodel.WelfareViewModel

@Composable
fun DailyCheckInScreen(
    viewModel: WelfareViewModel,
    modifier: Modifier = Modifier,
    isDark: Boolean = false
) {
    val selectedFeeling by viewModel.selectedFeeling.collectAsState()
    val selectedStress by viewModel.selectedStress.collectAsState()
    val selectedFatigue by viewModel.selectedFatigue.collectAsState()
    val selectedRecovery by viewModel.selectedRecovery.collectAsState()
    val checkInNote by viewModel.checkInNote.collectAsState()
    val isSubmitting by viewModel.isCheckInSubmitting.collectAsState()
    val showSuccess by viewModel.showCheckInSuccessAnimation.collectAsState()

    // Confirmation Animation Overlay
    if (showSuccess) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(if (isDark) Navy900 else Color.White)
                .padding(24.dp)
                .testTag("checkin_success_screen"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(StatusStable.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = StatusStable,
                        modifier = Modifier.size(52.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Check-in completed",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Thank you for taking a moment for yourself.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                PrivacyAssuranceChip(
                    text = "Stored Securely & Anonymously",
                    isDark = isDark
                )
            }
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
        }

        // Header
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Daily Voluntary Check-in",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    PrivacyAssuranceChip(text = "100% Confidential", isDark = isDark)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your honest reflection helps you maintain self-awareness and wellness.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Question 1: How are you feeling today?
        item {
            QuestionCard(
                questionNumber = "01",
                questionTitle = "How are you feeling today?",
                subtitle = "Select the expression closest to your current state",
                isDark = isDark
            ) {
                val feelingOptions = listOf(
                    Triple(1, "Very Low", Icons.Default.SentimentVeryDissatisfied),
                    Triple(2, "Low", Icons.Default.SentimentDissatisfied),
                    Triple(3, "Neutral", Icons.Default.SentimentNeutral),
                    Triple(4, "Good", Icons.Default.SentimentSatisfied),
                    Triple(5, "Very Good", Icons.Default.SentimentVerySatisfied)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    feelingOptions.forEach { (scale, label, icon) ->
                        val isSelected = (selectedFeeling == scale)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { viewModel.setFeeling(scale) }
                                .background(
                                    if (isSelected) (if (isDark) Color(0xFF1E3A8A) else Color(0xFFEFF6FF))
                                    else (if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC))
                                )
                                .border(
                                    if (isSelected) 2.dp else 1.dp,
                                    if (isSelected) (if (isDark) Indigo500 else Color(0xFF2563EB))
                                    else (if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)),
                                    RoundedCornerShape(14.dp)
                                )
                                .padding(vertical = 12.dp, horizontal = 4.dp)
                                .testTag("feeling_option_$scale")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isSelected) (if (isDark) Indigo500 else Color(0xFF2563EB))
                                        else (if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9))
                                    )
                                    .border(
                                        1.5.dp,
                                        if (isSelected) (if (isDark) Color(0xFF93C5FD) else Color(0xFFBFDBFE))
                                        else (if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = if (isSelected) Color.White else (if (isDark) Color(0xFFCBD5E1) else Color(0xFF334155)),
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                color = if (isSelected) (if (isDark) Color(0xFF93C5FD) else Color(0xFF1E40AF))
                                else MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // Question 2: How would you describe your stress today?
        item {
            QuestionCard(
                questionNumber = "02",
                questionTitle = "How would you describe your stress today?",
                subtitle = "Reflect on duty, mission, and personal demands",
                isDark = isDark
            ) {
                val stressOptions = listOf("Very Low", "Low", "Moderate", "High", "Very High")
                SegmentedChoiceRow(
                    options = stressOptions,
                    selectedIndex = selectedStress - 1,
                    onSelect = { viewModel.setStress(it + 1) },
                    isDark = isDark,
                    testTagPrefix = "stress_option"
                )
            }
        }

        // Question 3: How fatigued do you feel?
        item {
            QuestionCard(
                questionNumber = "03",
                questionTitle = "How fatigued do you feel?",
                subtitle = "Consider physical exhaustion and cognitive fatigue",
                isDark = isDark
            ) {
                val fatigueOptions = listOf("No Fatigue", "Mild", "Moderate", "High", "Severe")
                SegmentedChoiceRow(
                    options = fatigueOptions,
                    selectedIndex = selectedFatigue - 1,
                    onSelect = { viewModel.setFatigue(it + 1) },
                    isDark = isDark,
                    testTagPrefix = "fatigue_option"
                )
            }
        }

        // Question 4: How was your recovery?
        item {
            QuestionCard(
                questionNumber = "04",
                questionTitle = "How was your recovery?",
                subtitle = "Sleep quality, rest periods, and downtime effectiveness",
                isDark = isDark
            ) {
                val recoveryOptions = listOf("Poor", "Below Avg", "Average", "Good", "Excellent")
                SegmentedChoiceRow(
                    options = recoveryOptions,
                    selectedIndex = selectedRecovery - 1,
                    onSelect = { viewModel.setRecovery(it + 1) },
                    isDark = isDark,
                    testTagPrefix = "recovery_option"
                )
            }
        }

        // Optional Note
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) Navy800 else Color.White
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isDark) Color(0xFF334155) else BorderLight
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Optional Note",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Is there anything you would like to add?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = checkInNote,
                        onValueChange = { viewModel.setNote(it) },
                        placeholder = {
                            Text(
                                "e.g., Night watch shift, extended convoy, good restful sleep...",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("checkin_note_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Indigo500,
                            unfocusedBorderColor = if (isDark) Color(0xFF334155) else BorderLight
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = Indigo500,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Optional. Your note is not automatically used to generate AI predictions.",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Primary Submit Button
        item {
            Button(
                onClick = { viewModel.submitDailyCheckIn() },
                enabled = !isSubmitting,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDark) Color(0xFF2563EB) else Color(0xFF1E3A8A)
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("submit_checkin_button")
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Complete Check-in",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun QuestionCard(
    questionNumber: String,
    questionTitle: String,
    subtitle: String,
    isDark: Boolean,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Navy800 else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 1.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0xFF1E3A8A) else Color(0xFFEFF6FF))
                        .border(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFBFDBFE), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = questionNumber,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color(0xFF93C5FD) else Color(0xFF1E3A8A)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = questionTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            content()
        }
    }
}

@Composable
private fun SegmentedChoiceRow(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    isDark: Boolean,
    testTagPrefix: String
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isDark) Color(0xFF0F172A) else Color(0xFFF1F5F9),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            options.forEachIndexed { idx, label ->
                val isSelected = (idx == selectedIndex)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (isSelected) {
                                if (isDark) Color(0xFF2563EB) else Color(0xFF1E3A8A)
                            } else {
                                if (isDark) Color(0xFF1E293B) else Color.White
                            }
                        )
                        .border(
                            if (isSelected) 1.5.dp else 1.dp,
                            if (isSelected) {
                                if (isDark) Color(0xFF93C5FD) else Color(0xFF1E3A8A)
                            } else {
                                if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)
                            },
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelect(idx) }
                        .padding(vertical = 14.dp, horizontal = 2.dp)
                        .testTag("${testTagPrefix}_$idx"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                        color = if (isSelected) {
                            Color.White
                        } else {
                            if (isDark) Color(0xFFCBD5E1) else Color(0xFF1E293B)
                        },
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

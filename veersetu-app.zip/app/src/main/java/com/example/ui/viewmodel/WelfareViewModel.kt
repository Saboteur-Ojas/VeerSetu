package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Appointment
import com.example.data.model.AuditAccessLog
import com.example.data.model.CheckInEntry
import com.example.data.model.PersonnelProfile
import com.example.data.model.RetentionZone
import com.example.data.repository.WelfareRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class PersonnelTab(val label: String) {
    HOME("Home"),
    CHECK_IN("Check-in"),
    SUPPORT("Support"),
    PRIVACY("Privacy")
}

class WelfareViewModel(
    private val repository: WelfareRepository = WelfareRepository()
) : ViewModel() {

    // Auth & Profile
    val isLoggedIn: StateFlow<Boolean> = repository.isLoggedIn
    val currentUser: StateFlow<PersonnelProfile?> = repository.currentUser

    // Navigation
    private val _currentTab = MutableStateFlow(PersonnelTab.HOME)
    val currentTab: StateFlow<PersonnelTab> = _currentTab.asStateFlow()

    // Daily Check-in
    val hasCheckedInToday: StateFlow<Boolean> = repository.hasCheckedInToday
    val todayCheckIn: StateFlow<CheckInEntry?> = repository.todayCheckIn
    val checkInHistory: StateFlow<List<CheckInEntry>> = repository.checkInHistory

    // Appointments & Audit
    val appointments: StateFlow<List<Appointment>> = repository.appointments
    val auditLogs: StateFlow<List<AuditAccessLog>> = repository.auditLogs

    // Privacy settings
    val sharePseudonymousWithCounsellor = repository.sharePseudonymousWithCounsellor
    val contributeAggregateUnitMetrics = repository.contributeAggregateUnitMetrics
    val operationalContextSync = repository.operationalContextSync

    // Theme Mode (Default: Light Mode as requested by user)
    val isDarkMode: StateFlow<Boolean> = repository.isDarkMode

    // Check-in Form in-progress
    private val _selectedFeeling = MutableStateFlow(4) // 1..5
    val selectedFeeling: StateFlow<Int> = _selectedFeeling.asStateFlow()

    private val _selectedStress = MutableStateFlow(2) // 1..5
    val selectedStress: StateFlow<Int> = _selectedStress.asStateFlow()

    private val _selectedFatigue = MutableStateFlow(2) // 1..5
    val selectedFatigue: StateFlow<Int> = _selectedFatigue.asStateFlow()

    private val _selectedRecovery = MutableStateFlow(4) // 1..5
    val selectedRecovery: StateFlow<Int> = _selectedRecovery.asStateFlow()

    private val _checkInNote = MutableStateFlow("")
    val checkInNote: StateFlow<String> = _checkInNote.asStateFlow()

    private val _isCheckInSubmitting = MutableStateFlow(false)
    val isCheckInSubmitting: StateFlow<Boolean> = _isCheckInSubmitting.asStateFlow()

    private val _showCheckInSuccessAnimation = MutableStateFlow(false)
    val showCheckInSuccessAnimation: StateFlow<Boolean> = _showCheckInSuccessAnimation.asStateFlow()

    // Modals
    private val _showProfileModal = MutableStateFlow(false)
    val showProfileModal: StateFlow<Boolean> = _showProfileModal.asStateFlow()

    private val _showAppointmentBookingModal = MutableStateFlow(false)
    val showAppointmentBookingModal: StateFlow<Boolean> = _showAppointmentBookingModal.asStateFlow()

    private val _showSupportRequestModal = MutableStateFlow(false)
    val showSupportRequestModal: StateFlow<Boolean> = _showSupportRequestModal.asStateFlow()

    private val _showLearnMoreSheet = MutableStateFlow(false)
    val showLearnMoreSheet: StateFlow<Boolean> = _showLearnMoreSheet.asStateFlow()

    private val _bookingSuccessMessage = MutableStateFlow<String?>(null)
    val bookingSuccessMessage: StateFlow<String?> = _bookingSuccessMessage.asStateFlow()

    fun selectTab(tab: PersonnelTab) {
        _currentTab.value = tab
    }

    // Auth methods
    fun login(
        serviceId: String,
        email: String,
        retentionZone: RetentionZone = RetentionZone.HIGH
    ): Boolean {
        return repository.login(serviceId, email, retentionZone)
    }

    fun register(
        serviceId: String,
        email: String,
        phoneNumber: String,
        retentionZone: RetentionZone = RetentionZone.HIGH
    ): Boolean {
        return repository.register(serviceId, email, phoneNumber, retentionZone)
    }

    fun logout() {
        repository.logout()
        _currentTab.value = PersonnelTab.HOME
        _showProfileModal.value = false
    }

    // Check-in setters
    fun setFeeling(level: Int) {
        _selectedFeeling.value = level
    }

    fun setStress(level: Int) {
        _selectedStress.value = level
    }

    fun setFatigue(level: Int) {
        _selectedFatigue.value = level
    }

    fun setRecovery(level: Int) {
        _selectedRecovery.value = level
    }

    fun setNote(note: String) {
        _checkInNote.value = note
    }

    fun submitDailyCheckIn() {
        viewModelScope.launch {
            _isCheckInSubmitting.value = true
            delay(400)
            repository.submitCheckIn(
                feeling = _selectedFeeling.value,
                stress = _selectedStress.value,
                fatigue = _selectedFatigue.value,
                recovery = _selectedRecovery.value,
                note = _checkInNote.value
            )
            _isCheckInSubmitting.value = false
            _showCheckInSuccessAnimation.value = true
            delay(1500)
            _showCheckInSuccessAnimation.value = false
            _currentTab.value = PersonnelTab.HOME
        }
    }

    fun openProfileModal() {
        _showProfileModal.value = true
    }

    fun closeProfileModal() {
        _showProfileModal.value = false
    }

    fun openAppointmentBooking() {
        _showAppointmentBookingModal.value = true
    }

    fun closeAppointmentBooking() {
        _showAppointmentBookingModal.value = false
    }

    fun openSupportRequest() {
        _showSupportRequestModal.value = true
    }

    fun closeSupportRequest() {
        _showSupportRequestModal.value = false
    }

    fun openLearnMore() {
        _showLearnMoreSheet.value = true
    }

    fun closeLearnMore() {
        _showLearnMoreSheet.value = false
    }

    fun bookAppointment(
        role: String,
        dateText: String,
        timeSlot: String,
        mode: String,
        notes: String
    ) {
        viewModelScope.launch {
            repository.bookAppointment(role, dateText, timeSlot, mode, notes)
            _showAppointmentBookingModal.value = false
            _bookingSuccessMessage.value = "Confidential appointment requested for $dateText at $timeSlot"
            delay(3500)
            _bookingSuccessMessage.value = null
        }
    }

    fun togglePseudonymousSharing(enabled: Boolean) {
        repository.togglePseudonymousSharing(enabled)
    }

    fun toggleAggregateSharing(enabled: Boolean) {
        repository.toggleAggregateSharing(enabled)
    }

    fun toggleOperationalContextSync(enabled: Boolean) {
        repository.toggleOperationalContextSync(enabled)
    }

    fun toggleDarkMode() {
        repository.toggleDarkMode()
    }

    fun setDarkMode(enabled: Boolean) {
        repository.setDarkMode(enabled)
    }
}

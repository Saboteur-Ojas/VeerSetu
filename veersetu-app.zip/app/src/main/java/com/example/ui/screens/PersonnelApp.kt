package com.example.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AppointmentBookingDialog
import com.example.ui.components.LearnMoreBottomSheet
import com.example.ui.components.OfficerProfileModal
import com.example.ui.components.SupportRequestDialog
import com.example.ui.components.VeerSetuTopBar
import com.example.ui.theme.Indigo500
import com.example.ui.theme.Navy900
import com.example.ui.viewmodel.PersonnelTab
import com.example.ui.viewmodel.WelfareViewModel

@Composable
fun PersonnelApp(
    viewModel: WelfareViewModel = viewModel(),
    isDark: Boolean = isSystemInDarkTheme()
) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val showProfileModal by viewModel.showProfileModal.collectAsState()
    val showBookingModal by viewModel.showAppointmentBookingModal.collectAsState()
    val showSupportModal by viewModel.showSupportRequestModal.collectAsState()
    val showLearnMoreSheet by viewModel.showLearnMoreSheet.collectAsState()

    // If not authenticated, display Login / Register Screen
    if (!isLoggedIn) {
        AuthScreen(
            viewModel = viewModel,
            isDark = isDark,
            onThemeToggle = { viewModel.toggleDarkMode() }
        )
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            VeerSetuTopBar(
                onProfileClick = { viewModel.openProfileModal() },
                isDark = isDark,
                onThemeToggle = { viewModel.toggleDarkMode() }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = if (isDark) Navy900 else Color.White,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .border(
                        androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isDark) Color(0xFF1E293B) else Color(0xFFE2E8F0)
                        )
                    )
                    .testTag("personnel_bottom_nav")
            ) {
                // Home Tab
                NavigationBarItem(
                    selected = currentTab == PersonnelTab.HOME,
                    onClick = { viewModel.selectTab(PersonnelTab.HOME) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = {
                        Text(
                            text = "Home",
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == PersonnelTab.HOME) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = if (isDark) Indigo500 else Color(0xFF1E3A8A),
                        indicatorColor = if (isDark) Indigo500 else Color(0xFF2563EB),
                        unselectedIconColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                        unselectedTextColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_tab_home")
                )

                // Check-in Tab
                NavigationBarItem(
                    selected = currentTab == PersonnelTab.CHECK_IN,
                    onClick = { viewModel.selectTab(PersonnelTab.CHECK_IN) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = "Check-in"
                        )
                    },
                    label = {
                        Text(
                            text = "Check-in",
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == PersonnelTab.CHECK_IN) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = if (isDark) Indigo500 else Color(0xFF1E3A8A),
                        indicatorColor = if (isDark) Indigo500 else Color(0xFF2563EB),
                        unselectedIconColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                        unselectedTextColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_tab_checkin")
                )

                // Support Tab
                NavigationBarItem(
                    selected = currentTab == PersonnelTab.SUPPORT,
                    onClick = { viewModel.selectTab(PersonnelTab.SUPPORT) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.SupportAgent,
                            contentDescription = "Support"
                        )
                    },
                    label = {
                        Text(
                            text = "Support",
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == PersonnelTab.SUPPORT) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = if (isDark) Indigo500 else Color(0xFF1E3A8A),
                        indicatorColor = if (isDark) Indigo500 else Color(0xFF2563EB),
                        unselectedIconColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                        unselectedTextColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_tab_support")
                )

                // Privacy Tab
                NavigationBarItem(
                    selected = currentTab == PersonnelTab.PRIVACY,
                    onClick = { viewModel.selectTab(PersonnelTab.PRIVACY) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Privacy"
                        )
                    },
                    label = {
                        Text(
                            text = "Privacy",
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == PersonnelTab.PRIVACY) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = if (isDark) Indigo500 else Color(0xFF1E3A8A),
                        indicatorColor = if (isDark) Indigo500 else Color(0xFF2563EB),
                        unselectedIconColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                        unselectedTextColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_tab_privacy")
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentTab, label = "tab_crossfade") { tab ->
                when (tab) {
                    PersonnelTab.HOME -> PersonnelHomeScreen(
                        viewModel = viewModel,
                        isDark = isDark
                    )
                    PersonnelTab.CHECK_IN -> DailyCheckInScreen(
                        viewModel = viewModel,
                        isDark = isDark
                    )
                    PersonnelTab.SUPPORT -> SupportAppointmentsScreen(
                        viewModel = viewModel,
                        isDark = isDark
                    )
                    PersonnelTab.PRIVACY -> PrivacyCenterScreen(
                        viewModel = viewModel,
                        isDark = isDark
                    )
                }
            }
        }
    }

    // Modals
    if (showProfileModal) {
        OfficerProfileModal(
            profile = currentUser,
            onLogout = { viewModel.logout() },
            onDismiss = { viewModel.closeProfileModal() },
            isDark = isDark,
            onSetDarkMode = { viewModel.setDarkMode(it) }
        )
    }

    if (showBookingModal) {
        AppointmentBookingDialog(
            onDismiss = { viewModel.closeAppointmentBooking() },
            onBook = { role, date, slot, mode, notes ->
                viewModel.bookAppointment(role, date, slot, mode, notes)
            },
            isDark = isDark
        )
    }

    if (showSupportModal) {
        SupportRequestDialog(
            onDismiss = { viewModel.closeSupportRequest() },
            onSubmit = { /* Submitted */ },
            isDark = isDark
        )
    }

    if (showLearnMoreSheet) {
        LearnMoreBottomSheet(
            onDismiss = { viewModel.closeLearnMore() },
            isDark = isDark
        )
    }
}

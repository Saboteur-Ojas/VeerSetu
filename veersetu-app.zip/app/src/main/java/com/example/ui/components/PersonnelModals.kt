package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Headset
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderLight
import com.example.ui.theme.Indigo100
import com.example.ui.theme.Indigo50
import com.example.ui.theme.Indigo500
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.StatusStable
import com.example.ui.theme.Teal600

@Composable
fun AppointmentBookingDialog(
    onDismiss: () -> Unit,
    onBook: (role: String, date: String, slot: String, mode: String, notes: String) -> Unit,
    isDark: Boolean = false
) {
    var selectedDate by remember { mutableStateOf("Fri, Sep 05") }
    var selectedSlot by remember { mutableStateOf("10:30 AM") }
    var selectedRole by remember { mutableStateOf("Duty Welfare Officer") }
    var selectedMode by remember { mutableStateOf("Confidential In-Person") }
    var bookingNotes by remember { mutableStateOf("") }

    val dateOptions = listOf("Fri, Sep 05", "Sat, Sep 06", "Mon, Sep 08", "Tue, Sep 09", "Wed, Sep 10")
    val slotOptions = listOf("09:30 AM", "10:30 AM", "02:00 PM", "03:30 PM", "05:00 PM")
    val modeOptions = listOf("Confidential In-Person", "Encrypted Voice", "Secure Video")
    val roleOptions = listOf("Duty Welfare Officer", "Senior Psychologist", "Peer Support Officer")

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth().testTag("appointment_booking_dialog"),
        shape = RoundedCornerShape(20.dp),
        containerColor = if (isDark) Navy800 else Color.White,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Book Support Session",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PrivacyAssuranceChip(text = "Zero Command Notification", isDark = isDark)

                // Date Picker row
                Text("Select Date", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(dateOptions.size) { idx ->
                        val date = dateOptions[idx]
                        val isSelected = (date == selectedDate)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) (if (isDark) Indigo500 else Color(0xFF2563EB)) else (if (isDark) Navy900 else Color(0xFFF1F5F9)))
                                .border(1.dp, if (isSelected) (if (isDark) Indigo500 else Color(0xFF2563EB)) else (if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)), RoundedCornerShape(8.dp))
                                .clickable { selectedDate = date }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = date,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Time Slots row
                Text("Available Time Slot", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(slotOptions.size) { idx ->
                        val slot = slotOptions[idx]
                        val isSelected = (slot == selectedSlot)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) (if (isDark) Indigo500 else Color(0xFF2563EB)) else (if (isDark) Navy900 else Color(0xFFF1F5F9)))
                                .border(1.dp, if (isSelected) (if (isDark) Indigo500 else Color(0xFF2563EB)) else (if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)), RoundedCornerShape(8.dp))
                                .clickable { selectedSlot = slot }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = slot,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Channel / Mode
                Text("Consultation Channel", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    modeOptions.forEach { mode ->
                        val isSelected = (mode == selectedMode)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) (if (isDark) Color(0xFF0D9488) else Color(0xFF059669)) else (if (isDark) Navy900 else Color(0xFFF1F5F9)))
                                .border(1.dp, if (isSelected) (if (isDark) Color(0xFF0D9488) else Color(0xFF059669)) else (if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)), RoundedCornerShape(8.dp))
                                .clickable { selectedMode = mode }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mode.replace("Confidential ", "").replace("Encrypted ", ""),
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Professional Role
                Text("Support Specialist", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    roleOptions.forEach { role ->
                        val isSelected = (role == selectedRole)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) (if (isDark) Color(0xFF1E3A8A) else Color(0xFFEFF6FF)) else Color.Transparent,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) (if (isDark) Indigo500 else Color(0xFF2563EB)) else (if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRole = role }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = role,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (isSelected) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        tint = if (isDark) Indigo500 else Color(0xFF2563EB),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onBook(selectedRole, selectedDate, selectedSlot, selectedMode, bookingNotes)
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDark) Indigo500 else Color(0xFF2563EB)
                ),
                modifier = Modifier.fillMaxWidth().testTag("confirm_booking_button")
            ) {
                Text("Confirm Confidential Request", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun SupportRequestDialog(
    onDismiss: () -> Unit,
    onSubmit: () -> Unit,
    isDark: Boolean = false
) {
    var urgency by remember { mutableStateOf("Routine Welfare") }
    var note by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(20.dp),
        containerColor = if (isDark) Navy800 else Color.White,
        modifier = Modifier.fillMaxWidth().testTag("support_request_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Request Support", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                }
            }
        },
        text = {
            if (submitted) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = StatusStable,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Support Ticket Created",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Ticket Code: CASE-VS-7A91-REQ\nA certified duty counsellor will review your pseudonymous request shortly.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Indigo500, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Routed pseudonymously under CASE-VS-7A91. Your identity is concealed.",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Text("Urgency Level", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Routine Welfare", "Within 24h", "Priority Support").forEach { item ->
                            val isSelected = (item == urgency)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) (if (isDark) Indigo500 else Color(0xFF2563EB)) else (if (isDark) Navy900 else Color(0xFFF1F5F9)))
                                    .border(1.dp, if (isSelected) (if (isDark) Indigo500 else Color(0xFF2563EB)) else (if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)), RoundedCornerShape(8.dp))
                                    .clickable { urgency = item }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = item,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Text("Context (Optional)", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        placeholder = { Text("Brief context or topics you wish to discuss...", style = MaterialTheme.typography.bodySmall) },
                        modifier = Modifier.fillMaxWidth().height(84.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = if (isDark) Indigo500 else Color(0xFF2563EB),
                            unfocusedBorderColor = if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)
                        )
                    )
                }
            }
        },
        confirmButton = {
            if (submitted) {
                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (isDark) Indigo500 else Color(0xFF2563EB)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = {
                        submitted = true
                        onSubmit()
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (isDark) Indigo500 else Color(0xFF2563EB)),
                    modifier = Modifier.fillMaxWidth().testTag("confirm_support_request_button")
                ) {
                    Text("Submit Request", fontWeight = FontWeight.Bold)
                }
            }
        }
    )
}

@Composable
fun OfficerProfileModal(
    profile: com.example.data.model.PersonnelProfile?,
    onLogout: () -> Unit,
    onDismiss: () -> Unit,
    isDark: Boolean = false,
    onSetDarkMode: (Boolean) -> Unit = {}
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(20.dp),
        containerColor = if (isDark) Navy800 else Color.White,
        modifier = Modifier.fillMaxWidth().testTag("officer_profile_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = Indigo500, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Personnel Dossier", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isDark) Color(0xFF334155) else BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ProfileInfoRow("Service ID", profile?.serviceId ?: "DEF-9842-OP", isDark)
                        ProfileInfoRow("Official Email", profile?.email ?: "officer@defense.gov.in", isDark)
                        ProfileInfoRow("Phone Number", profile?.phoneNumber ?: "+91 98450 12345", isDark)
                        ProfileInfoRow("VeerSetu Pseudonym", profile?.pseudonym ?: "CASE-VS-7A91", isDark)
                        ProfileInfoRow("Encryption", "AES-256 HSM Local Vault", isDark)
                    }
                }

                // Theme Mode Selector Option
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isDark) Color(0xFF334155) else BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Display Theme",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isDark) "Dark Mode" else "Light Mode (Default)",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDark) Color(0xFF93C5FD) else Color(0xFF16A34A)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Light Option
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (!isDark) Indigo500 else (if (isDark) Navy800 else Color(0xFFF1F5F9)),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (!isDark) Indigo500 else (if (isDark) Color(0xFF334155) else BorderLight)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onSetDarkMode(false) }
                                    .testTag("modal_theme_light")
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LightMode,
                                        contentDescription = "Light Mode",
                                        tint = if (!isDark) Color.White else (if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Light",
                                        fontSize = 12.sp,
                                        fontWeight = if (!isDark) FontWeight.Bold else FontWeight.Medium,
                                        color = if (!isDark) Color.White else (if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B))
                                    )
                                }
                            }

                            // Dark Option
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isDark) Indigo500 else Color(0xFFF1F5F9),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isDark) Indigo500 else BorderLight
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onSetDarkMode(true) }
                                    .testTag("modal_theme_dark")
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DarkMode,
                                        contentDescription = "Dark Mode",
                                        tint = if (isDark) Color.White else Color(0xFF64748B),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Dark",
                                        fontSize = 12.sp,
                                        fontWeight = if (isDark) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isDark) Color.White else Color(0xFF64748B)
                                    )
                                }
                            }
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isDark) Color(0xFF1E3A8A).copy(alpha = 0.4f) else Indigo50,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Indigo500, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Personnel Role Active. Your check-in records are protected under local cryptographic shielding.",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                OutlinedButton(
                    onClick = onLogout,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().testTag("btn_profile_logout")
                ) {
                    Text("Sign Out / Switch Service ID", fontWeight = FontWeight.SemiBold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (isDark) Indigo500 else Navy900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Close")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LearnMoreBottomSheet(
    onDismiss: () -> Unit,
    isDark: Boolean = false
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = if (isDark) Navy800 else Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Understanding VeerSetu Welfare Support",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Text(
                text = "VeerSetu provides timely personnel welfare while strictly safeguarding personal privacy.",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Indigo500
            )

            Text(
                text = "In high-stress operational postings, fatigue and operational pressure fluctuate normally. VeerSetu allows personnel to voluntarily log personal wellness state and access confidential professional support without fear of surveillance.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 22.sp
            )

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isDark) Color(0xFF334155) else BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Key Welfare Foundations:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text("• Voluntary Self-Reflection: Take moments to reflect on rest and fatigue.", style = MaterialTheme.typography.bodySmall)
                    Text("• Zero Surveillance: No tracking, no diagnosis, no punitive flags.", style = MaterialTheme.typography.bodySmall)
                    Text("• Certified Human Support: Coordinate confidential sessions with duty professionals at any time.", style = MaterialTheme.typography.bodySmall)
                }
            }

            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (isDark) Indigo500 else Navy900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Understood", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ProfileInfoRow(label: String, value: String, isDark: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
    }
}

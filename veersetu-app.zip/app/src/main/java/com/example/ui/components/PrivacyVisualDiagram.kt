package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderLight
import com.example.ui.theme.Indigo50
import com.example.ui.theme.Indigo500
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.StatusStable

@Composable
fun PrivacyVisualDiagram(
    modifier: Modifier = Modifier,
    isDark: Boolean = false
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Navy800 else Color.White
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isDark) Color(0xFF334155) else BorderLight
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0xFF1E3A8A) else Indigo50),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = Indigo500,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Who Can See What?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Cryptographic Separation of Roles",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tier 1: Personnel (You)
            PrivacyTierRow(
                roleTitle = "Personnel (You)",
                badgeText = "Personal Information",
                badgeBg = if (isDark) Color(0xFF064E3B) else Color(0xFFECFDF5),
                badgeTextColor = if (isDark) Color(0xFF6EE7B7) else Color(0xFF065F46),
                icon = Icons.Default.Person,
                description = "Your identifiable service profile, complete check-in history, personal notes, and confidential appointments.",
                canSeeName = true,
                canSeeNotes = true,
                canSeeCheckIns = true,
                isDark = isDark
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Tier 2: Counsellor
            PrivacyTierRow(
                roleTitle = "Counsellor",
                badgeText = "Pseudonymous Welfare Profile",
                badgeBg = if (isDark) Color(0xFF1E3A8A) else Color(0xFFEFF6FF),
                badgeTextColor = if (isDark) Color(0xFF93C5FD) else Color(0xFF1D4ED8),
                icon = Icons.Default.Psychology,
                description = "Pseudonymous session coordinates only (e.g. CASE-VS-7A91). Real name, personal notes, and telephone remain strictly masked.",
                canSeeName = false,
                canSeeNotes = false,
                canSeeCheckIns = true,
                isDark = isDark
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Tier 3: Commander
            PrivacyTierRow(
                roleTitle = "Commander",
                badgeText = "Aggregate Unit Overview",
                badgeBg = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9),
                badgeTextColor = if (isDark) Color(0xFFCBD5E1) else Color(0xFF475569),
                icon = Icons.Default.Analytics,
                description = "Aggregated unit completion percentages across battalions. Zero individual records, check-ins, or personal traces.",
                canSeeName = false,
                canSeeNotes = false,
                canSeeCheckIns = false,
                isDark = isDark
            )

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Indigo500,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Zero Surveillance Guarantee: No biometric eavesdropping, location tracking, or punitive flagging.",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun PrivacyTierRow(
    roleTitle: String,
    badgeText: String,
    badgeBg: Color,
    badgeTextColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    canSeeName: Boolean,
    canSeeNotes: Boolean,
    canSeeCheckIns: Boolean,
    isDark: Boolean
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isDark) Color(0xFF1E293B) else Color(0xFFE2E8F0)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isDark) Color(0xFF94A3B8) else Navy900,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = roleTitle,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(badgeBg)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = badgeTextColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.5.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PermissionCheckItem("Service ID", canSeeName, isDark)
                PermissionCheckItem("Personal Notes", canSeeNotes, isDark)
                PermissionCheckItem("Check-in State", canSeeCheckIns, isDark)
            }
        }
    }
}

@Composable
private fun PermissionCheckItem(label: String, allowed: Boolean, isDark: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = if (allowed) Icons.Default.Check else Icons.Default.Close,
            contentDescription = null,
            tint = if (allowed) StatusStable else (if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)),
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            color = if (allowed) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

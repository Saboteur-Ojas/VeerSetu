package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.RetentionZone
import com.example.data.repository.WelfareRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("VeerSetu", appName)
  }

  @Test
  fun `user registration sets service id, email, phone, and retention zone`() {
    val repository = WelfareRepository()
    val success = repository.register(
      serviceId = "DEF-5521-OP",
      email = "captain.kumar@defense.gov.in",
      phoneNumber = "+91 99887 76655",
      retentionZone = RetentionZone.MID
    )
    assertTrue(success)
    val user = repository.currentUser.value
    assertNotNull(user)
    assertEquals("DEF-5521-OP", user?.serviceId)
    assertEquals("captain.kumar@defense.gov.in", user?.email)
    assertEquals("+91 99887 76655", user?.phoneNumber)
    assertEquals(RetentionZone.MID, user?.retentionZone)
    assertTrue(repository.isLoggedIn.value)
  }

  @Test
  fun `submitting checkin updates today state`() = runBlocking {
    val repository = WelfareRepository()
    repository.submitCheckIn(feeling = 5, stress = 1, fatigue = 2, recovery = 5, note = "Duty post clear")
    assertTrue(repository.hasCheckedInToday.value)
    assertNotNull(repository.todayCheckIn.value)
    assertEquals(5, repository.todayCheckIn.value?.feelingLevel)
  }

  @Test
  fun `logout updates isLoggedIn state`() {
    val repository = WelfareRepository()
    assertTrue(repository.isLoggedIn.value)
    repository.logout()
    assertFalse(repository.isLoggedIn.value)
  }

  @Test
  fun `login with different retention zone options`() {
    val repository = WelfareRepository()
    
    // Test login with MID retention zone
    val midSuccess = repository.login(
      serviceId = "DEF-1001-OP",
      email = "major.singh@defense.gov.in",
      retentionZone = RetentionZone.MID
    )
    assertTrue(midSuccess)
    assertEquals(RetentionZone.MID, repository.currentUser.value?.retentionZone)
    assertEquals("DEF-1001-OP", repository.currentUser.value?.serviceId)

    // Test login with LOW retention zone
    val lowSuccess = repository.login(
      serviceId = "DEF-1002-OP",
      email = "subedar.patel@defense.gov.in",
      retentionZone = RetentionZone.LOW
    )
    assertTrue(lowSuccess)
    assertEquals(RetentionZone.LOW, repository.currentUser.value?.retentionZone)

    // Test login with HIGH retention zone
    val highSuccess = repository.login(
      serviceId = "DEF-1003-OP",
      email = "lieutenant.joshi@defense.gov.in",
      retentionZone = RetentionZone.HIGH
    )
    assertTrue(highSuccess)
    assertEquals(RetentionZone.HIGH, repository.currentUser.value?.retentionZone)
  }
}

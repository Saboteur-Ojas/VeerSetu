package com.example

import com.example.data.repository.WelfareRepository
import com.example.ui.viewmodel.WelfareViewModel
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testThemeDefaultsToLightMode() {
    val repository = WelfareRepository()
    val viewModel = WelfareViewModel(repository)

    // Verify default is light mode (false)
    assertFalse(viewModel.isDarkMode.value)
  }

  @Test
  fun testThemeToggleAndSetDarkMode() {
    val repository = WelfareRepository()
    val viewModel = WelfareViewModel(repository)

    // Default: light mode
    assertFalse(viewModel.isDarkMode.value)

    // Toggle to dark mode
    viewModel.toggleDarkMode()
    assertTrue(viewModel.isDarkMode.value)

    // Toggle back to light mode
    viewModel.toggleDarkMode()
    assertFalse(viewModel.isDarkMode.value)

    // Explicit set
    viewModel.setDarkMode(true)
    assertTrue(viewModel.isDarkMode.value)

    viewModel.setDarkMode(false)
    assertFalse(viewModel.isDarkMode.value)
  }
}
